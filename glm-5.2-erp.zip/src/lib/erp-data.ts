// GLM 5.2 ERP — central mock data store
// Nobel-grade simulation: predictive analytics, AI insights, blockchain ledger, IoT telemetry

export type Branch = {
  id: string;
  name: string;
  nameAr: string;
  isMain?: boolean;
};

export type ErpUser = {
  id: string;
  name: string;
  role: "admin" | "sales" | "accountant" | "warehouse";
  branchId: string;
  avatar?: string;
};

export const BRANCHES: Branch[] = [
  { id: "br1", nameAr: "الفرع الرئيسى", name: "Main Branch", isMain: true },
  { id: "br2", nameAr: "فرع المعادى", name: "Maadi Branch" },
  { id: "br3", nameAr: "فرع مدينة نصر", name: "Nasr City Branch" },
  { id: "br4", nameAr: "فرع الإسكندرية", name: "Alexandria Branch" },
];

export const USERS: ErpUser[] = [
  { id: "u1", name: "Admin", role: "admin", branchId: "br1" },
  { id: "u2", name: "Sales Manager", role: "sales", branchId: "br1" },
  { id: "u3", name: "Chief Accountant", role: "accountant", branchId: "br1" },
  { id: "u4", name: "Warehouse Lead", role: "warehouse", branchId: "br1" },
];

// KPIs — animated counters
export const KPIS = [
  {
    id: "revenue",
    label: "إجمالي المبيعات",
    labelEn: "Total Revenue",
    value: 4872500,
    currency: "EGP",
    delta: 12.4,
    spark: [32, 38, 35, 42, 45, 48, 52, 56, 58, 61, 64, 68],
    icon: "trending-up",
    accent: "emerald" as const,
  },
  {
    id: "purchases",
    label: "إجمالي المشتريات",
    labelEn: "Total Purchases",
    value: 2148900,
    currency: "EGP",
    delta: -3.2,
    spark: [28, 26, 27, 24, 25, 22, 23, 21, 22, 20, 21, 19],
    icon: "shopping-cart",
    accent: "gold" as const,
  },
  {
    id: "expenses",
    label: "المصروفات التشغيلية",
    labelEn: "Operating Expenses",
    value: 687300,
    currency: "EGP",
    delta: 4.8,
    spark: [12, 13, 12, 14, 15, 14, 16, 17, 18, 17, 19, 20],
    icon: "wallet",
    accent: "magenta" as const,
  },
  {
    id: "treasury",
    label: "الرصيد النقدي",
    labelEn: "Treasury Balance",
    value: 2037300,
    currency: "EGP",
    delta: 8.1,
    spark: [40, 42, 45, 48, 52, 55, 58, 62, 65, 68, 72, 76],
    icon: "landmark",
    accent: "teal" as const,
  },
  {
    id: "receivables",
    label: "الذمم المدينة",
    labelEn: "Receivables",
    value: 924500,
    currency: "EGP",
    delta: -1.4,
    spark: [30, 29, 30, 28, 29, 27, 28, 26, 27, 26, 25, 24],
    icon: "file-text",
    accent: "amber" as const,
  },
  {
    id: "aiDecisions",
    label: "قرارات الذكاء الاصطناعي",
    labelEn: "AI Decisions Today",
    value: 1287,
    currency: "",
    delta: 22.5,
    spark: [120, 145, 138, 162, 178, 190, 205, 220, 238, 256, 272, 289],
    icon: "brain",
    accent: "emerald" as const,
  },
];

// Analytics table (per branch)
export const BRANCH_ANALYTICS = BRANCHES.map((b, i) => ({
  branch: b.nameAr,
  sales: [0, 1245000, 845000, 620000][i] ?? 0,
  purchases: [0, 524000, 384000, 280000][i] ?? 0,
  expenses: [0, 187000, 132000, 98000][i] ?? 0,
  treasury: [25000, 480000, 720000, 340000][i] ?? 0,
  total: [25000, 1726000, 1566000, 1240000][i] ?? 0,
  cash: [2000, 180000, 240000, 120000][i] ?? 0,
  visa: [6800, 320000, 280000, 180000][i] ?? 0,
  credit: [0, 540000, 480000, 360000][i] ?? 0,
}));

// Sales chart — last 12 months
export const MONTHLY_SALES = [
  { m: "ينا", sales: 285000, purchases: 142000, target: 300000 },
  { m: "فبر", sales: 312000, purchases: 158000, target: 320000 },
  { m: "مار", sales: 298000, purchases: 165000, target: 320000 },
  { m: "أبر", sales: 345000, purchases: 178000, target: 340000 },
  { m: "ماي", sales: 388000, purchases: 184000, target: 360000 },
  { m: "يون", sales: 412000, purchases: 195000, target: 400000 },
  { m: "يول", sales: 425000, purchases: 210000, target: 420000 },
  { m: "أغس", sales: 398000, purchases: 198000, target: 420000 },
  { m: "سبت", sales: 448000, purchases: 220000, target: 440000 },
  { m: "أكت", sales: 472000, purchases: 232000, target: 460000 },
  { m: "نوف", sales: 510000, purchases: 248000, target: 480000 },
  { m: "ديس", sales: 578000, purchases: 268000, target: 520000 },
];

// Predictive forecast (AI-generated) — next 6 months
export const FORECAST = [
  { m: "ينا 27", predicted: 612000, confidence: 0.94, low: 580000, high: 645000 },
  { m: "فبر 27", predicted: 648000, confidence: 0.91, low: 605000, high: 692000 },
  { m: "مار 27", predicted: 672000, confidence: 0.88, low: 622000, high: 722000 },
  { m: "أبر 27", predicted: 695000, confidence: 0.85, low: 635000, high: 755000 },
  { m: "ماي 27", predicted: 718000, confidence: 0.82, low: 650000, high: 786000 },
  { m: "يون 27", predicted: 745000, confidence: 0.78, low: 668000, high: 822000 },
];

// AI Insights (Nobel-grade research outputs)
export const AI_INSIGHTS = [
  {
    id: "ins1",
    title: "نبذة تنبؤية: ذروة الطلب في يوليو",
    titleEn: "Forecast: Peak demand in July",
    body: "نموذج GLM 5.2 التنبؤي يرصد ارتفاع الطلب على منتجات الموسم بنسبة 38% في يوليو. يُوصى بزيادة المخزون بنسبة 25% قبل 15 يونيو.",
    severity: "info" as const,
    confidence: 0.94,
    tag: "Forecasting",
  },
  {
    id: "ins2",
    title: "كشف احتيال محتمل: فاتورة مكررة",
    titleEn: "Fraud detection: duplicate invoice",
    body: "رصد محرك الكشف الذكي فاتورتين متطابقتين بقيمة 84,500 ج.م من نفس المورد خلال 48 ساعة. يتطلب المراجعة قبل الاعتماد.",
    severity: "warning" as const,
    confidence: 0.88,
    tag: "Fraud Detection",
  },
  {
    id: "ins3",
    title: "تحسين سلسلة التوريد",
    titleEn: "Supply chain optimization",
    body: "خوارزمية أوميغا تقترح إعادة توجيه 18% من المشتريات إلى المورد B لتقليل التكلفة بنسبة 4.2% دون التأثير على زمن التسليم.",
    severity: "success" as const,
    confidence: 0.91,
    tag: "Optimization",
  },
  {
    id: "ins4",
    title: "تحذير سيولة نقدية",
    titleEn: "Liquidity warning",
    body: "بناءً على نمط التدفق النقدي الحالي، قد ينخفض رصيد الخزينة إلى ما دون الحد الآمن خلال 9 أيام. يُوصى بتسريع تحصيل 3 ذمم مدينة.",
    severity: "warning" as const,
    confidence: 0.86,
    tag: "Treasury",
  },
  {
    id: "ins5",
    title: "فرصة تسعير ديناميكي",
    titleEn: "Dynamic pricing opportunity",
    body: "ذكاء التسعير يرصد مرونة سعرية مرتفعة في 6 منتجات. تطبيق تسعير ديناميكي قد يرفع هامش الربح بنسبة 7.8%.",
    severity: "info" as const,
    confidence: 0.79,
    tag: "Pricing AI",
  },
];

// Smart alerts (header bell)
export const SMART_ALERTS = [
  {
    id: "al1",
    title: "استحقاقات عملاء",
    body: "لديك عدد 2 من استحقاقات العملاء اليوم بقيمة 184,500 ج.م",
    time: "01:13 م",
    severity: "warning" as const,
  },
  {
    id: "al2",
    title: "مخزون منخفض",
    body: "5 أصناف وصلت للحد الأدنى وتحتاج إعادة طلب فورية",
    time: "11:42 ص",
    severity: "danger" as const,
  },
  {
    id: "al3",
    title: "اقتراح ذكاء اصطناعي",
    body: "GLM 5.2 يرصد نمطاً غير معتاد في فواتير المبيعات — مراجعة موصى بها",
    time: "10:18 ص",
    severity: "info" as const,
  },
  {
    id: "al4",
    title: "موافقة معلقة",
    body: "أمر شراء بقيمة 245,000 ج.م بانتظار اعتمادك",
    time: "أمس",
    severity: "info" as const,
  },
];

// Sales invoices — recent
export const RECENT_INVOICES = [
  { id: "INV-2026-0148", customer: "شركة النيل للتجارة", amount: 84500, status: "paid", date: "2026/06/22", aiScore: 0.94 },
  { id: "INV-2026-0147", customer: "مؤسسة الأهرام", amount: 32200, status: "pending", date: "2026/06/22", aiScore: 0.88 },
  { id: "INV-2026-0146", customer: "شركة سفنكس", amount: 124800, status: "paid", date: "2026/06/21", aiScore: 0.91 },
  { id: "INV-2026-0145", customer: "متاجر كايرو", amount: 18700, status: "overdue", date: "2026/06/19", aiScore: 0.62 },
  { id: "INV-2026-0144", customer: "بازار رمسيس", amount: 56300, status: "paid", date: "2026/06/18", aiScore: 0.85 },
  { id: "INV-2026-0143", customer: "شركة المعمورة", amount: 78400, status: "pending", date: "2026/06/18", aiScore: 0.79 },
];

// Warehouses — IoT telemetry
export const WAREHOUSES = [
  { id: "w1", name: "المخزن الرئيسي", location: "القاهرة", capacity: 12000, used: 8450, temp: 22.4, humidity: 45, items: 1248, aiStock: 0.92 },
  { id: "w2", name: "مخزن المعادى", location: "القاهرة", capacity: 8000, used: 5680, temp: 23.1, humidity: 48, items: 824, aiStock: 0.78 },
  { id: "w3", name: "مخزن الإسكندرية", location: "الإسكندرية", capacity: 10000, used: 4120, temp: 24.8, humidity: 62, items: 612, aiStock: 0.65 },
  { id: "w4", name: "مخزن الطرق", location: "متعدد", capacity: 5000, used: 3240, temp: 26.2, humidity: 38, items: 412, aiStock: 0.88 },
];

// Inventory items (for sales)
export const INVENTORY_ITEMS = [
  { code: "ITM-001", name: "كرسي مكتب فاخر", unit: "قطعة", price: 1850, stock: 124, aiDemand: 0.88 },
  { code: "ITM-002", name: "طاولة اجتماعات L", unit: "قطعة", price: 4250, stock: 38, aiDemand: 0.72 },
  { code: "ITM-003", name: "خزانة ملفات معدنية", unit: "قطعة", price: 1240, stock: 8, aiDemand: 0.94 },
  { code: "ITM-004", name: "شاشة عرض 55 بوصة", unit: "قطعة", price: 8900, stock: 22, aiDemand: 0.81 },
  { code: "ITM-005", name: "نظام صوتيات مكتب", unit: "طقم", price: 3650, stock: 18, aiDemand: 0.69 },
  { code: "ITM-006", name: "حاسب محمول ProBook", unit: "قطعة", price: 24800, stock: 6, aiDemand: 0.92 },
];

// Customers
export const CUSTOMERS = [
  { id: "c1", name: "شركة النيل للتجارة", balance: 124500, creditLimit: 500000, rating: "A", aiRisk: 0.12 },
  { id: "c2", name: "مؤسسة الأهرام", balance: 32200, creditLimit: 200000, rating: "B", aiRisk: 0.28 },
  { id: "c3", name: "شركة سفنكس", balance: 0, creditLimit: 800000, rating: "A", aiRisk: 0.08 },
  { id: "c4", name: "متاجر كايرو", balance: -18700, creditLimit: 100000, rating: "C", aiRisk: 0.62 },
  { id: "c5", name: "بازار رمسيس", balance: 0, creditLimit: 250000, rating: "B", aiRisk: 0.34 },
];

// Blockchain audit trail (mock ledger)
export const BLOCKCHAIN_LEDGER = [
  { hash: "0x7f3a…2b91", block: 1842501, type: "إنشاء فاتورة", amount: 84500, ts: "13:14:22", validator: "GLM-5.2" },
  { hash: "0xa814…9c45", block: 1842500, type: "تحصيل نقدي", amount: 25000, ts: "13:02:18", validator: "GLM-5.2" },
  { hash: "0x3c2e…7d12", block: 1842499, type: "إذن صرف مخزن", amount: 0, ts: "12:48:55", validator: "GLM-5.2" },
  { hash: "0xb592…1a87", block: 1842498, type: "تسوية بنكية", amount: 184500, ts: "12:30:11", validator: "GLM-5.2" },
  { hash: "0xe601…4f33", block: 1842497, type: "أمر شراء", amount: 245000, ts: "11:55:42", validator: "GLM-5.2" },
];

// Nobel Prize plan — innovation pillars
export const NOBEL_PILLARS = [
  {
    id: "p1",
    title: "محرك التنبؤ الكمي",
    titleEn: "Quantum Prediction Engine",
    body: "نموذج تسلسلي عميق (32 طبقة) يدرس 4.2 مليون نقطة بيانات يومياً، يتوقع الطلب والسيولة والمخاطر بدقة 94.2% على أفق 90 يوم.",
    metric: "94.2%",
    metricLabel: "دقة التنبؤ",
    icon: "brain",
  },
  {
    id: "p2",
    title: "سجل التدقيق الكتلي",
    titleEn: "Blockchain Audit Ledger",
    body: "كل عملية مالية موقعة تشفيرياً ومسجلة في سلسلة كتلات موزعة. لا يمكن التلاعب بأي قيد بعد اعتماده — معيار أمني يفوق المعايير المصرفية.",
    metric: "1.84M",
    metricLabel: "كتلة موثقة",
    icon: "shield",
  },
  {
    id: "p3",
    title: "تشفير مقاوم للكم",
    titleEn: "Quantum-Safe Encryption",
    body: "خوارزميات CRYSTALS-Kyber و Dilithium متاحة افتراضياً. بياناتك محمية ضد أجهزة الكم المستقبلية لعقود قادمة.",
    metric: "256-bit",
    metricLabel: "مستوى الحماية",
    icon: "lock",
  },
  {
    id: "p4",
    title: "كشف الاحتيال العصبي",
    titleEn: "Neural Fraud Detection",
    body: "شبكة GNN تربط 14 علاقة بين الكيانات (موردين، عملاء، حسابات، فواتير) لتكشف أنماط الاحتيال غير المرئية للمراجع البشري في وقت حقيقي.",
    metric: "0.88s",
    metricLabel: "زمن الكشف",
    icon: "alert-triangle",
  },
  {
    id: "p5",
    title: "محرك التسعير الديناميكي",
    titleEn: "Dynamic Pricing Engine",
    body: "نموذج مرونة سعرية يتكيف مع 23 متغيراً (طلب، موسم، منافسة، مخزون) في وقت حقيقي لرفع هامش الربح 7-12% دون فقدان حصة السوق.",
    metric: "+9.4%",
    metricLabel: "تحسين الهامش",
    icon: "tag",
  },
  {
    id: "p6",
    title: "محادثة لغة طبيعية",
    titleEn: "Natural Language Co-pilot",
    body: "اسأل بالعربية أو الإنجليزية: \"ما أعلى 5 عملاء مخاطرة هذا الشهر؟\" — يحلل، يرسم، يصدّر. تكامل صوتي كامل لاستخدام بلا يدين.",
    metric: "12ms",
    metricLabel: "زمن الاستجابة",
    icon: "message-square",
  },
];

// AI co-pilot — starter prompts
export const AI_PROMPTS = [
  "ما أعلى 5 عملاء مخاطرة هذا الشهر؟",
  "توقع تدفقي النقدي للأسبوع القادم",
  "اقترح خطة لإعادة ترتيب المخزون",
  "ما أنماط الاحتيال المرصودة اليوم؟",
  "حلّل هامش ربح منتج ITM-006",
  "كيف أقلل مصروفات الخزينة بـ 15%؟",
];

// Calendar events (follow-ups)
export const CALENDAR_EVENTS = [
  { id: "ev1", date: "2026-06-23", time: "10:00", title: "اجتماع مراجعة المبيعات", type: "meeting", priority: "high" },
  { id: "ev2", date: "2026-06-23", time: "13:30", title: "تحصيل ذمم شركة النيل", type: "task", priority: "high" },
  { id: "ev3", date: "2026-06-24", time: "11:00", title: "مراجعة جرد مخزن المعادى", type: "task", priority: "medium" },
  { id: "ev4", date: "2026-06-24", time: "15:00", title: "اعتماد أوامر الشراء", type: "approval", priority: "high" },
  { id: "ev5", date: "2026-06-25", time: "09:30", title: "تسوية بنك HSBC", type: "task", priority: "medium" },
  { id: "ev6", date: "2026-06-26", time: "12:00", title: "اجتماع مجلس الإدارة", type: "meeting", priority: "high" },
];

export function formatCurrency(value: number, currency = "EGP"): string {
  if (!value) return "0.00";
  return new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(value);
}

export function formatCompact(value: number): string {
  if (Math.abs(value) >= 1_000_000) return (value / 1_000_000).toFixed(2) + "M";
  if (Math.abs(value) >= 1_000) return (value / 1_000).toFixed(1) + "K";
  return value.toString();
}
