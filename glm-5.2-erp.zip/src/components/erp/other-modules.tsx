"use client";
import { Icon } from "./icons";
import { AI_INSIGHTS, MONTHLY_SALES, KPIS, formatCompact } from "@/lib/erp-data";
import { toast } from "sonner";

export function ReportsModule() {
  const reportTypes = [
    { id: "sales", label: "تقرير المبيعات", icon: "trending-up", color: "text-emerald-400" },
    { id: "purchases", label: "تقرير المشتريات", icon: "shopping-cart", color: "text-amber-400" },
    { id: "treasury", label: "تقرير الخزينة", icon: "wallet", color: "text-teal-400" },
    { id: "customers", label: "تقرير العملاء", icon: "user", color: "text-pink-400" },
    { id: "inventory", label: "تقرير المخزون", icon: "boxes", color: "text-orange-400" },
    { id: "tax", label: "التقرير الضريبي", icon: "file-text", color: "text-emerald-400" },
    { id: "audit", label: "تقريد التدقيق", icon: "shield", color: "text-amber-400" },
    { id: "forecast", label: "تقرير التنبؤ", icon: "brain", color: "text-emerald-400" },
  ];

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold">التقارير</h1>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
              <Icon name="brain" className="w-2.5 h-2.5" />
              مولّد تلقائياً
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">تقارير ذكية تُكتب وتُحلَّل بمعرفة GLM 5.2</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => toast.success("تم تصدير PDF")} className="px-3 py-2 rounded-xl glass text-xs hover:bg-white/10 transition flex items-center gap-1.5">
            <Icon name="printer" className="w-3.5 h-3.5" />
            طباعة
          </button>
          <button onClick={() => toast.success("تم تصدير Excel")} className="px-3 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 text-black text-xs font-semibold hover:from-emerald-400 hover:to-emerald-500 transition flex items-center gap-1.5">
            <Icon name="download" className="w-3.5 h-3.5" />
            تصدير Excel
          </button>
        </div>
      </div>

      {/* AI-generated executive summary */}
      <div className="glass-strong rounded-2xl p-5">
        <div className="flex items-center justify-between mb-3">
          <h3 className="text-sm font-semibold flex items-center gap-2">
            <Icon name="sparkles" className="w-4 h-4 text-amber-400" />
            الملخص التنفيذي الذكي
          </h3>
          <span className="text-[9px] text-muted-foreground">وُلِّد الآن · 0.8 ثانية</span>
        </div>
        <div className="text-xs leading-relaxed text-muted-foreground space-y-2">
          <p>
            <span className="text-foreground font-semibold">الأداء العام: </span>
            سجّلت المؤسسة نمواً صحيّاً في الـ 30 يوماً الماضية، حيث ارتفعت المبيعات بنسبة
            <span className="text-emerald-400 font-semibold"> 12.4%</span> لتصل إلى
            <span className="num text-emerald-400 font-semibold"> {formatCompact(KPIS[0].value)} ج.م</span>،
            مع انخفاض طفيف في المشتريات بنسبة <span className="text-amber-400">3.2%</span>.
          </p>
          <p>
            <span className="text-foreground font-semibold">المخاطر المرصودة: </span>
            رصد محرك الكشف الذكي <span className="text-pink-400 font-semibold">فاتورة مكررة محتملة</span>
            بقيمة 84,500 ج.م، وذمم متأخرة بقيمة 18,700 ج.م منذ 3 أيام. التوصية: تفعيل التحصيل الآلي خلال 48 ساعة.
          </p>
          <p>
            <span className="text-foreground font-semibold">الفرص: </span>
            يرصد محرك التسعير الديناميكي مرونة سعرية في 6 منتجات. تطبيق تسعير متكيّف قد يرفع الهامش
            بنسبة <span className="text-emerald-400 font-semibold">7.8%</span> دون فقدان حصة السوق.
          </p>
          <p>
            <span className="text-foreground font-semibold">التوقع: </span>
            بناءً على نموذج التنبؤ الكمي (دقة 94.2%)، يُتوقع استمرار النمو في الربع القادم بنسبة 18.4%،
            مع ضرورة زيادة المخزون بنسبة 25% قبل 15 يونيو لمواكبة ذروة الطلب.
          </p>
        </div>
      </div>

      {/* Report types */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {reportTypes.map((r) => (
          <button
            key={r.id}
            onClick={() => toast.info(`جارٍ توليد ${r.label}...`, { description: "سيُعَدّ تلقائياً خلال 3 ثوانٍ" })}
            className="glass rounded-2xl p-4 text-right hover:border-white/20 transition group hover:scale-[1.02]"
          >
            <div className={`w-10 h-10 rounded-xl bg-white/5 ${r.color} flex items-center justify-center mb-2.5 group-hover:scale-110 transition`}>
              <Icon name={r.icon} className="w-5 h-5" />
            </div>
            <div className="text-xs font-semibold mb-0.5">{r.label}</div>
            <div className="text-[9px] text-muted-foreground flex items-center gap-1">
              <Icon name="sparkles" className="w-2.5 h-2.5" />
              توليد ذكي
            </div>
          </button>
        ))}
      </div>

      {/* Insights + chart */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        <div className="glass rounded-2xl p-5 xl:col-span-2">
          <h3 className="text-sm font-semibold flex items-center gap-2 mb-4">
            <Icon name="trending-up" className="w-4 h-4 text-emerald-400" />
            اتجاه المبيعات السنوي
          </h3>
          <div className="flex items-end justify-between gap-1 h-40">
            {MONTHLY_SALES.map((m, i) => {
              const max = Math.max(...MONTHLY_SALES.map((x) => x.sales));
              return (
                <div key={m.m} className="flex-1 flex flex-col items-center gap-1.5 group">
                  <div className="relative w-full flex flex-col items-center justify-end h-full">
                    <div
                      className="w-full rounded-t bg-gradient-to-t from-emerald-500/40 to-emerald-400 group-hover:from-emerald-400 group-hover:to-emerald-300 transition-all"
                      style={{ height: `${(m.sales / max) * 100}%` }}
                    >
                      <span className="absolute -top-5 left-1/2 -translate-x-1/2 text-[9px] font-mono opacity-0 group-hover:opacity-100 transition bg-background px-1 py-0.5 rounded">
                        {formatCompact(m.sales)}
                      </span>
                    </div>
                  </div>
                  <span className="text-[9px] text-muted-foreground">{i + 1}</span>
                </div>
              );
            })}
          </div>
          <div className="mt-3 pt-3 border-t border-white/5 grid grid-cols-3 gap-3 text-center">
            <div>
              <div className="text-xs font-bold text-emerald-400 num">{formatCompact(KPIS[0].value)}</div>
              <div className="text-[9px] text-muted-foreground">إجمالي المبيعات</div>
            </div>
            <div>
              <div className="text-xs font-bold text-amber-400 num">+12.4%</div>
              <div className="text-[9px] text-muted-foreground">النمو السنوي</div>
            </div>
            <div>
              <div className="text-xs font-bold text-teal-400 num">+18.4%</div>
              <div className="text-[9px] text-muted-foreground">التوقع القادم</div>
            </div>
          </div>
        </div>

        <div className="glass rounded-2xl p-5">
          <h3 className="text-sm font-semibold flex items-center gap-2 mb-3">
            <Icon name="sparkles" className="w-4 h-4 text-amber-400" />
            توصيات ذكية
          </h3>
          <div className="space-y-2 max-h-72 overflow-y-auto scroll-thin">
            {AI_INSIGHTS.map((ins) => (
              <div key={ins.id} className={`p-2.5 rounded-xl border ${
                ins.severity === "warning" ? "border-amber-500/20 bg-amber-500/5" :
                ins.severity === "success" ? "border-emerald-500/20 bg-emerald-500/5" : "border-pink-500/20 bg-pink-500/5"
              }`}>
                <div className="text-[11px] font-semibold mb-0.5">{ins.title}</div>
                <p className="text-[10px] text-muted-foreground leading-relaxed">{ins.body}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

export function TreasuryModule() {
  const accounts = [
    { id: "t1", name: "الخزينة الرئيسية", balance: 1037300, type: "cash", change: 8.1 },
    { id: "t2", name: "بنك HSBC", balance: 524800, type: "bank", change: 4.2 },
    { id: "t3", name: "بنك القاهرة", balance: 312400, type: "bank", change: -1.8 },
    { id: "t4", name: "صندوق المصروفات", balance: 84500, type: "cash", change: 2.4 },
    { id: "t5", name: "بنك الإسكندرية", balance: 78300, type: "bank", change: 5.6 },
  ];
  const total = accounts.reduce((s, a) => s + a.balance, 0);

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold">الخزينة</h1>
        <p className="text-xs text-muted-foreground mt-0.5">إدارة السيولة النقدية والمصرفية مع توقع تلقائي للتدفقات</p>
      </div>

      <div className="glass-strong rounded-2xl p-5 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="text-[10px] text-muted-foreground">إجمالي السيولة المتاحة</div>
          <div className="text-3xl font-bold gradient-text num">{total.toLocaleString("en-US")} <span className="text-sm">ج.م</span></div>
          <div className="text-[10px] text-emerald-400 mt-0.5">+5.4% عن الأسبوع الماضي</div>
        </div>
        <div className="grid grid-cols-2 gap-3 w-full sm:w-auto">
          <div className="px-4 py-2 rounded-xl glass">
            <div className="text-[9px] text-muted-foreground">توقع 7 أيام</div>
            <div className="text-sm font-bold text-emerald-400 num">+184K</div>
          </div>
          <div className="px-4 py-2 rounded-xl glass">
            <div className="text-[9px] text-muted-foreground">تنبيه سيولة</div>
            <div className="text-sm font-bold text-amber-400">منخفض</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-3">
        {accounts.map((a) => (
          <div key={a.id} className="glass rounded-2xl p-4 hover:border-white/20 transition">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-2">
                <div className={`w-9 h-9 rounded-lg ${a.type === "cash" ? "bg-emerald-500/15" : "bg-amber-500/15"} flex items-center justify-center`}>
                  <Icon name={a.type === "cash" ? "wallet" : "banknote"} className={`w-4 h-4 ${a.type === "cash" ? "text-emerald-400" : "text-amber-400"}`} />
                </div>
                <div>
                  <div className="text-xs font-semibold">{a.name}</div>
                  <div className="text-[9px] text-muted-foreground">{a.type === "cash" ? "نقدية" : "حساب بنكي"}</div>
                </div>
              </div>
              <span className={`text-[10px] font-semibold flex items-center gap-0.5 ${a.change >= 0 ? "text-emerald-400" : "text-red-400"}`}>
                <Icon name={a.change >= 0 ? "arrow-up-right" : "arrow-down-right"} className="w-3 h-3" />
                {Math.abs(a.change)}%
              </span>
            </div>
            <div className="text-xl font-bold num">{a.balance.toLocaleString("en-US")}</div>
            <div className="text-[9px] text-muted-foreground">ج.م</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function CalendarModule() {
  const events = [
    { id: "ev1", date: "2026-06-23", time: "10:00", title: "اجتماع مراجعة المبيعات", type: "meeting", priority: "high" },
    { id: "ev2", date: "2026-06-23", time: "13:30", title: "تحصيل ذمم شركة النيل", type: "task", priority: "high" },
    { id: "ev3", date: "2026-06-24", time: "11:00", title: "مراجعة جرد مخزن المعادى", type: "task", priority: "medium" },
    { id: "ev4", date: "2026-06-24", time: "15:00", title: "اعتماد أوامر الشراء", type: "approval", priority: "high" },
    { id: "ev5", date: "2026-06-25", time: "09:30", title: "تسوية بنك HSBC", type: "task", priority: "medium" },
    { id: "ev6", date: "2026-06-26", time: "12:00", title: "اجتماع مجلس الإدارة", type: "meeting", priority: "high" },
    { id: "ev7", date: "2026-06-26", time: "16:00", title: "مراجعة التوقعات الشهرية", type: "task", priority: "low" },
    { id: "ev8", date: "2026-06-27", time: "10:30", title: "تدريب الفريق على GLM 5.2", type: "meeting", priority: "medium" },
  ];

  const typeColors: Record<string, string> = {
    meeting: "bg-emerald-500/15 text-emerald-400 border-emerald-500/20",
    task: "bg-amber-500/15 text-amber-400 border-amber-500/20",
    approval: "bg-pink-500/15 text-pink-400 border-pink-500/20",
  };
  const typeLabels: Record<string, string> = {
    meeting: "اجتماع",
    task: "مهمة",
    approval: "اعتماد",
  };

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold">التقويم</h1>
        <p className="text-xs text-muted-foreground mt-0.5">متابعة المهام والاجتماعات والاعتمادات</p>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        <div className="xl:col-span-2 space-y-2">
          {events.map((ev) => (
            <div key={ev.id} className="glass rounded-2xl p-3.5 flex items-center gap-3 hover:border-white/20 transition group">
              <div className="text-center shrink-0 w-12">
                <div className="text-[9px] text-muted-foreground">يونيو</div>
                <div className="text-xl font-bold num">{ev.date.slice(-2)}</div>
              </div>
              <div className="w-px h-10 bg-white/10" />
              <div className="flex-1 min-w-0">
                <div className="text-xs font-medium">{ev.title}</div>
                <div className="text-[10px] text-muted-foreground flex items-center gap-2 mt-0.5">
                  <span className="num">{ev.time}</span>
                  <span className={`px-1.5 py-0.5 rounded border ${typeColors[ev.type]}`}>{typeLabels[ev.type]}</span>
                  {ev.priority === "high" && (
                    <span className="text-amber-400 flex items-center gap-0.5">
                      <Icon name="alert-triangle" className="w-2.5 h-2.5" />
                      أولوية عالية
                    </span>
                  )}
                </div>
              </div>
              <button className="opacity-0 group-hover:opacity-100 transition p-2 rounded-lg hover:bg-white/5">
                <Icon name="chevron-left" className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>
          ))}
        </div>

        <div className="glass rounded-2xl p-5">
          <h3 className="text-sm font-semibold flex items-center gap-2 mb-4">
            <Icon name="brain" className="w-4 h-4 text-emerald-400" />
            توقيت ذكي
          </h3>
          <p className="text-[10px] text-muted-foreground leading-relaxed mb-3">
            يحلّل GLM 5.2 أولوياتك وأنماط عملك ويقترح أفضل الأوقات لكل مهمة.
          </p>
          <div className="space-y-2">
            <div className="p-2.5 rounded-xl bg-emerald-500/5 border border-emerald-500/20">
              <div className="text-[10px] text-emerald-300 font-semibold mb-1">اقتراح</div>
              <p className="text-[10px] text-muted-foreground">نقل اجتماع مراجعة المبيعات إلى 9:00 ص — ذروة إنتاجيتك.</p>
            </div>
            <div className="p-2.5 rounded-xl bg-amber-500/5 border border-amber-500/20">
              <div className="text-[10px] text-amber-300 font-semibold mb-1">تحذير</div>
              <p className="text-[10px] text-muted-foreground">3 مهام عالية الأولوية مكدّسة الخميس — موصى بتوزيعها.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function SettingsModule() {
  const settings = [
    { id: "ai", title: "إعدادات الذكاء الاصطناعي", icon: "brain", items: [
      { label: "تفعيل المساعد الذكي", value: true },
      { label: "كشف الاحتيال التلقائي", value: true },
      { label: "التسعير الديناميكي", value: true },
      { label: "توقعات المخزون", value: true },
    ]},
    { id: "security", title: "الأمان والتشفير", icon: "lock", items: [
      { label: "تشفير مقاوم للكم", value: true },
      { label: "المصادقة الثنائية", value: false },
      { label: "سجل التدقيق الكتلي", value: true },
      { label: "تسجيل الخروج التلقائي (30 د)", value: true },
    ]},
    { id: "ui", title: "الواجهة والعرض", icon: "settings", items: [
      { label: "الوضع الليلي", value: true },
      { label: "حركات الانتقال", value: true },
      { label: "إشعارات سطح المكتب", value: false },
      { label: "اللغة: العربية", value: true },
    ]},
  ];

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold">إعدادات البرنامج</h1>
        <p className="text-xs text-muted-foreground mt-0.5">تخصيص النظام والتفضيلات</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {settings.map((s) => (
          <div key={s.id} className="glass rounded-2xl p-5">
            <h3 className="text-sm font-semibold flex items-center gap-2 mb-4">
              <Icon name={s.icon} className="w-4 h-4 text-emerald-400" />
              {s.title}
            </h3>
            <div className="space-y-3">
              {s.items.map((it, i) => (
                <label key={i} className="flex items-center justify-between gap-2 cursor-pointer">
                  <span className="text-xs text-muted-foreground">{it.label}</span>
                  <button
                    onClick={() => toast.info(`تم ${it.value ? "إيقاف" : "تفعيل"} ${it.label}`)}
                    className={`relative w-9 h-5 rounded-full transition ${it.value ? "bg-emerald-500" : "bg-muted"}`}
                  >
                    <span className={`absolute top-0.5 w-4 h-4 rounded-full bg-white transition-all ${it.value ? "left-0.5" : "right-0.5"}`} />
                  </button>
                </label>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="glass rounded-2xl p-5 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center">
            <Icon name="atom" className="w-5 h-5 text-black" />
          </div>
          <div>
            <div className="text-sm font-semibold">GLM 5.2 ERP</div>
            <div className="text-[10px] text-muted-foreground">الإصدار 5.2.0 · Nobel Edition</div>
          </div>
        </div>
        <div className="text-[10px] text-muted-foreground text-left">
          <div>© 2026 GLM 5.2 Labs</div>
          <div className="text-emerald-400">جميع الأنظمة تعمل بكفاءة</div>
        </div>
      </div>
    </div>
  );
}

export function PlaceholderModule({ title, icon, description }: { title: string; icon: string; description: string }) {
  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-2xl font-bold">{title}</h1>
        <p className="text-xs text-muted-foreground mt-0.5">{description}</p>
      </div>
      <div className="glass rounded-2xl p-12 text-center">
        <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-emerald-500/20 to-amber-500/20 border border-white/10 flex items-center justify-center mx-auto mb-4">
          <Icon name={icon} className="w-8 h-8 text-emerald-400" />
        </div>
        <h3 className="text-lg font-bold mb-2">وحدة {title}</h3>
        <p className="text-xs text-muted-foreground max-w-md mx-auto leading-relaxed mb-5">
          هذه الوحدة جزء من GLM 5.2 ERP الكامل. في النسخة الإنتاجية ستجد هنا كامل الأدوات المتكاملة
          لإدارة {title} بمساعدة الذكاء الاصطناعي.
        </p>
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-xs text-emerald-400">
          <Icon name="sparkles" className="w-3.5 h-3.5" />
          مدعوم بـ GLM 5.2
        </div>
      </div>
    </div>
  );
}
