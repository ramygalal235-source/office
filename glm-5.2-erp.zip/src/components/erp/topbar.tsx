"use client";
import { useEffect, useRef, useState } from "react";
import { Icon } from "./icons";
import { SMART_ALERTS, BRANCHES, USERS } from "@/lib/erp-data";
import { useClickOutside } from "@/hooks/use-click-outside";

type Props = {
  branchId: string;
  userId: string;
  onOpenCopilot: () => void;
  onLogout: () => void;
  onToggleTheme: () => void;
  theme: "dark" | "light";
};

export function Topbar({ branchId, userId, onOpenCopilot, onLogout, onToggleTheme, theme }: Props) {
  const [showAlerts, setShowAlerts] = useState(false);
  const [showUser, setShowUser] = useState(false);
  const [search, setSearch] = useState("");
  const [listening, setListening] = useState(false);
  const [now, setNow] = useState(new Date());

  const alertsBtnRef = useRef<HTMLButtonElement>(null);
  const alertsPanelRef = useRef<HTMLDivElement>(null);
  const userBtnRef = useRef<HTMLButtonElement>(null);
  const userPanelRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  // Click-outside handlers (replacing the fixed inset-0 backdrop that blocked adjacent buttons)
  useClickOutside(
    alertsPanelRef,
    () => setShowAlerts(false),
    showAlerts,
    [alertsBtnRef]
  );
  useClickOutside(
    userPanelRef,
    () => setShowUser(false),
    showUser,
    [userBtnRef]
  );

  // Close dropdowns on Escape
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setShowAlerts(false);
        setShowUser(false);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const branch = BRANCHES.find((b) => b.id === branchId);
  const user = USERS.find((u) => u.id === userId);
  const timeStr = now.toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit" });

  function toggleVoice() {
    setListening((v) => !v);
    if (!listening) {
      setTimeout(() => setListening(false), 2500);
    }
  }

  return (
    <header className="h-16 border-b border-border/60 bg-background/70 backdrop-blur-xl sticky top-0 z-30 flex items-center justify-between px-4 lg:px-6 gap-4">
      {/* Right side — branch + page */}
      <div className="flex items-center gap-3 min-w-0">
        <div className="flex items-center gap-2.5 px-3 py-1.5 rounded-lg glass">
          <Icon name="building" className="w-3.5 h-3.5 text-primary shrink-0" />
          <span className="text-sm font-medium truncate">{branch?.nameAr ?? "—"}</span>
          <span className="text-[10px] text-muted-foreground hidden sm:inline">·</span>
          <span className="text-xs text-muted-foreground hidden sm:inline">{user?.name}</span>
        </div>
        <div className="hidden md:flex items-center gap-1.5 text-xs text-muted-foreground">
          <span className="num">{timeStr}</span>
          <span>·</span>
          <span className="flex items-center gap-1 text-emerald-500">
            <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full pulse-glow" />
            متصل
          </span>
        </div>
      </div>

      {/* Center — AI search */}
      <div className="hidden lg:flex flex-1 max-w-xl items-center relative">
        <div className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground">
          <Icon name="search" className="w-4 h-4" />
        </div>
        <input
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="اسأل GLM 5.2 أو ابحث... (مثال: توقع مبيعات يوليو)"
          className="w-full bg-input/40 border border-border/40 rounded-xl pr-10 pl-24 py-2.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/30 focus:border-primary/30 transition placeholder:text-muted-foreground/60"
          onKeyDown={(e) => { if (e.key === "Enter" && search.trim()) onOpenCopilot(); }}
        />
        <div className="absolute left-2 top-1/2 -translate-y-1/2 flex items-center gap-1">
          <button
            onClick={toggleVoice}
            className={`p-1.5 rounded-lg transition ${listening ? "bg-red-500/20 text-red-500" : "text-muted-foreground hover:text-foreground hover:bg-foreground/5"}`}
            aria-label="بحث صوتي"
            title="بحث صوتي"
          >
            <Icon name="mic" className={`w-4 h-4 ${listening ? "animate-pulse" : ""}`} />
          </button>
          <kbd className="hidden xl:inline-flex items-center gap-0.5 px-1.5 py-0.5 text-[9px] font-mono text-muted-foreground bg-muted/40 rounded">
            ⌘K
          </kbd>
        </div>
        {listening && (
          <div className="absolute top-full mt-2 right-0 left-0 glass-strong rounded-xl p-3 text-xs flex items-center gap-2 shadow-xl z-50">
            <span className="flex gap-0.5 items-end h-4">
              {[0, 1, 2, 3, 4].map((i) => (
                <span
                  key={i}
                  className="w-0.5 bg-primary rounded-full"
                  style={{ height: `${30 + Math.sin(Date.now() / 200 + i) * 50 + 30}%`, animation: "pulse-glow 0.6s infinite" }}
                />
              ))}
            </span>
            <span>جارٍ الاستماع... تكلّم الآن</span>
          </div>
        )}
      </div>

      {/* Left side — actions */}
      <div className="flex items-center gap-1.5">
        {/* AI Copilot */}
        <button
          onClick={onOpenCopilot}
          className="hidden sm:flex items-center gap-2 px-3 py-2 rounded-lg bg-gradient-to-r from-emerald-500/15 to-amber-500/15 border border-primary/20 hover:border-primary/40 transition relative z-10"
          title="مساعد GLM 5.2 (Cmd+K)"
        >
          <div className="relative">
            <Icon name="bot" className="w-4 h-4 text-primary" />
            <span className="absolute -top-0.5 -right-0.5 w-1.5 h-1.5 bg-primary rounded-full pulse-glow" />
          </div>
          <span className="text-xs font-medium">مساعد ذكي</span>
        </button>

        {/* Theme */}
        <button
          onClick={onToggleTheme}
          className="p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-foreground/5 transition relative z-10"
          aria-label="تبديل السمة"
          title="تبديل السمة"
        >
          <Icon name={theme === "dark" ? "sun" : "moon"} className="w-4 h-4" />
        </button>

        {/* Alerts */}
        <div className="relative">
          <button
            ref={alertsBtnRef}
            onClick={() => { setShowAlerts((v) => !v); setShowUser(false); }}
            className="relative p-2 rounded-lg text-muted-foreground hover:text-foreground hover:bg-foreground/5 transition"
            aria-label="التنبيهات"
            title="التنبيهات"
          >
            <Icon name="bell" className="w-4 h-4" />
            <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-amber-500 rounded-full pulse-glow" />
          </button>
          {showAlerts && (
            <div
              ref={alertsPanelRef}
              className="absolute left-0 mt-2 w-80 glass-strong rounded-2xl shadow-2xl border border-border/60 overflow-hidden z-50 float-up"
            >
              <div className="px-4 py-3 border-b border-border/40 flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Icon name="bell" className="w-4 h-4 text-amber-500" />
                  <span className="text-sm font-semibold">تنبيهات النظام</span>
                </div>
                <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-600 dark:text-amber-400">{SMART_ALERTS.length} جديد</span>
              </div>
              <div className="max-h-96 overflow-y-auto scroll-thin">
                {SMART_ALERTS.map((a) => (
                  <div key={a.id} className="px-4 py-3 hover:bg-foreground/[0.03] border-b border-border/30 cursor-pointer transition">
                    <div className="flex items-start gap-2.5">
                      <div className={`w-1.5 h-1.5 rounded-full mt-1.5 shrink-0 ${
                        a.severity === "danger" ? "bg-red-500" : a.severity === "warning" ? "bg-amber-500" : "bg-emerald-500"
                      }`} />
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-xs font-semibold truncate">{a.title}</span>
                          <span className="text-[10px] text-muted-foreground shrink-0 num">{a.time}</span>
                        </div>
                        <p className="text-[11px] text-muted-foreground mt-0.5 leading-relaxed">{a.body}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
              <button
                onClick={() => setShowAlerts(false)}
                className="w-full py-2.5 text-xs text-primary hover:bg-primary/10 transition border-t border-border/30"
              >
                عرض كل التنبيهات
              </button>
            </div>
          )}
        </div>

        {/* User menu */}
        <div className="relative">
          <button
            ref={userBtnRef}
            onClick={() => { setShowUser((v) => !v); setShowAlerts(false); }}
            className="flex items-center gap-2 px-2 py-1.5 rounded-lg hover:bg-foreground/5 transition"
          >
            <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-emerald-500 to-emerald-600 flex items-center justify-center text-xs font-bold text-white">
              {user?.name?.[0] ?? "U"}
            </div>
            <span className="text-xs font-medium hidden sm:inline">{user?.name}</span>
            <Icon name="chevron-down" className="w-3 h-3 text-muted-foreground hidden sm:inline" />
          </button>
          {showUser && (
            <div
              ref={userPanelRef}
              className="absolute left-0 mt-2 w-56 glass-strong rounded-2xl shadow-2xl border border-border/60 overflow-hidden z-50 float-up"
            >
              <div className="px-4 py-3 border-b border-border/30">
                <div className="text-sm font-semibold">{user?.name}</div>
                <div className="text-[10px] text-muted-foreground">{user?.role === "admin" ? "مدير النظام" : user?.role}</div>
              </div>
              <div className="py-1">
                <button
                  onClick={() => setShowUser(false)}
                  className="w-full px-4 py-2 flex items-center gap-2.5 text-xs hover:bg-foreground/5 transition text-right"
                >
                  <Icon name="user" className="w-3.5 h-3.5 text-muted-foreground" />
                  الملف الشخصي
                </button>
                <button
                  onClick={() => setShowUser(false)}
                  className="w-full px-4 py-2 flex items-center gap-2.5 text-xs hover:bg-foreground/5 transition text-right"
                >
                  <Icon name="settings" className="w-3.5 h-3.5 text-muted-foreground" />
                  الإعدادات
                </button>
                <button
                  onClick={() => setShowUser(false)}
                  className="w-full px-4 py-2 flex items-center gap-2.5 text-xs hover:bg-foreground/5 transition text-right"
                >
                  <Icon name="fingerprint" className="w-3.5 h-3.5 text-muted-foreground" />
                  المصادقة الثنائية
                </button>
              </div>
              <button
                onClick={() => { setShowUser(false); onLogout(); }}
                className="w-full px-4 py-2.5 flex items-center gap-2.5 text-xs hover:bg-red-500/10 text-red-500 transition border-t border-border/30 text-right"
              >
                <Icon name="logout" className="w-3.5 h-3.5" />
                تسجيل الخروج
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
