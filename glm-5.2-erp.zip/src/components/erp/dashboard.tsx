"use client";
import { useEffect, useState } from "react";
import { Icon } from "./icons";
import {
  KPIS,
  BRANCH_ANALYTICS,
  MONTHLY_SALES,
  FORECAST,
  AI_INSIGHTS,
  BLOCKCHAIN_LEDGER,
  RECENT_INVOICES,
  formatCurrency,
  formatCompact,
} from "@/lib/erp-data";

type Range = "today" | "yesterday" | "7d" | "month" | "year";

const RANGES: Array<{ key: Range; label: string }> = [
  { key: "today", label: "اليوم" },
  { key: "yesterday", label: "أمس" },
  { key: "7d", label: "آخر 7 أيام" },
  { key: "month", label: "هذا الشهر" },
  { key: "year", label: "هذه السنة" },
];

export function Dashboard() {
  const [range, setRange] = useState<Range>("month");
  const [animateCount, setAnimateCount] = useState(false);

  useEffect(() => {
    const t = setTimeout(() => setAnimateCount(true), 50);
    return () => clearTimeout(t);
  }, [range]);

  return (
    <div className="space-y-5">
      {/* Page title + range filter */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold">لوحة القيادة</h1>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
              <Icon name="brain" className="w-2.5 h-2.5" />
              مدعوم بـ GLM 5.2
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">إحصائية سريعة وتحليلات لحظية عبر الفروع</p>
        </div>
        <div className="flex items-center gap-1 p-1 rounded-xl glass">
          {RANGES.map((r) => (
            <button
              key={r.key}
              onClick={() => setRange(r.key)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition ${
                range === r.key ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>
      </div>

      {/* KPI grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-6 gap-3">
        {KPIS.map((kpi) => (
          <KpiCard key={kpi.id} kpi={kpi} animate={animateCount} />
        ))}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        <SalesChart />
        <ForecastChart />
      </div>

      {/* Analytics table + AI insights */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        <div className="xl:col-span-2 space-y-5">
          <AnalyticsTable />
          <RecentInvoices />
        </div>
        <div className="space-y-5">
          <AIInsights />
          <BlockchainTrail />
        </div>
      </div>
    </div>
  );
}

function KpiCard({ kpi, animate }: { kpi: typeof KPIS[number]; animate: boolean }) {
  const [val, setVal] = useState(0);
  useEffect(() => {
    if (!animate) {
      return;
    }
    const start = 0;
    const duration = 800;
    const startT = performance.now();
    let raf = 0;
    const tick = (t: number) => {
      const p = Math.min((t - startT) / duration, 1);
      const eased = 1 - Math.pow(1 - p, 3);
      setVal(Math.floor(start + (kpi.value - start) * eased));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [animate, kpi.value]);

  const accentMap: Record<string, string> = {
    emerald: "text-emerald-400 from-emerald-500/10",
    gold: "text-amber-400 from-amber-500/10",
    magenta: "text-pink-400 from-pink-500/10",
    teal: "text-teal-400 from-teal-500/10",
    amber: "text-orange-400 from-orange-500/10",
  };
  const accent = accentMap[kpi.accent] ?? accentMap.emerald;
  const positive = kpi.delta >= 0;

  return (
    <div className={`glass rounded-2xl p-4 relative overflow-hidden bg-gradient-to-br to-transparent ${accent.split(" ")[1]} group hover:border-white/20 transition`}>
      <div className="flex items-start justify-between mb-2.5">
        <div className={`p-2 rounded-lg bg-white/5 ${accent.split(" ")[0]}`}>
          <Icon name={kpi.icon} className="w-4 h-4" />
        </div>
        <span className={`text-[10px] font-semibold flex items-center gap-0.5 ${positive ? "text-emerald-400" : "text-red-400"}`}>
          <Icon name={positive ? "arrow-up-right" : "arrow-down-right"} className="w-3 h-3" />
          {Math.abs(kpi.delta)}%
        </span>
      </div>
      <div className="text-[10px] text-muted-foreground mb-0.5">{kpi.label}</div>
      <div className="text-xl font-bold num leading-tight">
        {kpi.currency ? `${formatCompact(val)} ` : val.toLocaleString("en-US")}
        {kpi.currency && <span className="text-[10px] text-muted-foreground mr-1">{kpi.currency}</span>}
      </div>
      {/* Spark */}
      <div className="mt-2 flex items-end gap-0.5 h-5">
        {kpi.spark.map((v, i) => (
          <div
            key={i}
            className={`flex-1 rounded-sm ${accent.split(" ")[0]} opacity-60 group-hover:opacity-100 transition`}
            style={{ height: `${(v / Math.max(...kpi.spark)) * 100}%` }}
          />
        ))}
      </div>
    </div>
  );
}

function SalesChart() {
  const max = Math.max(...MONTHLY_SALES.map((m) => Math.max(m.sales, m.target)));
  return (
    <div className="glass rounded-2xl p-5 xl:col-span-2">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-sm font-semibold flex items-center gap-2">
            <Icon name="trending-up" className="w-4 h-4 text-emerald-400" />
            المبيعات مقابل الهدف
          </h3>
          <p className="text-[10px] text-muted-foreground">آخر 12 شهر</p>
        </div>
        <div className="flex items-center gap-3 text-[10px]">
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-sm bg-emerald-400" />
            مبيعات
          </span>
          <span className="flex items-center gap-1">
            <span className="w-2.5 h-2.5 rounded-sm bg-amber-400/60" />
            هدف
          </span>
        </div>
      </div>
      <div className="flex items-end justify-between gap-1.5 h-48">
        {MONTHLY_SALES.map((m) => (
          <div key={m.m} className="flex-1 flex flex-col items-center gap-1.5 group">
            <div className="relative w-full flex flex-col items-center justify-end h-full gap-0.5">
              {/* Target line */}
              <div
                className="absolute inset-x-0 bg-amber-400/30 border-t border-dashed border-amber-400/60"
                style={{ bottom: `${(m.target / max) * 100}%`, height: 1 }}
              />
              {/* Sales bar */}
              <div
                className="w-full rounded-t bg-gradient-to-t from-emerald-500/60 to-emerald-400 hover:from-emerald-400 hover:to-emerald-300 transition-all relative"
                style={{ height: `${(m.sales / max) * 100}%` }}
              >
                <span className="absolute -top-5 left-1/2 -translate-x-1/2 text-[9px] font-mono opacity-0 group-hover:opacity-100 transition bg-background px-1 py-0.5 rounded">
                  {formatCompact(m.sales)}
                </span>
              </div>
            </div>
            <span className="text-[9px] text-muted-foreground">{m.m}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function ForecastChart() {
  const max = Math.max(...FORECAST.map((f) => f.high));
  return (
    <div className="glass rounded-2xl p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-sm font-semibold flex items-center gap-2">
            <Icon name="brain" className="w-4 h-4 text-amber-400" />
            توقع الذكاء الاصطناعي
          </h3>
          <p className="text-[10px] text-muted-foreground">الأشهر الـ 6 القادمة · دقة 94%</p>
        </div>
        <span className="text-[10px] px-2 py-0.5 rounded-full bg-amber-500/15 text-amber-400 border border-amber-500/20">
          Nobel-Grade
        </span>
      </div>
      <div className="flex items-end justify-between gap-2 h-48">
        {FORECAST.map((f) => (
          <div key={f.m} className="flex-1 flex flex-col items-center gap-1.5 group">
            <div className="relative w-full flex flex-col items-center justify-end h-full">
              {/* Confidence band */}
              <div
                className="absolute w-full bg-amber-400/15 rounded-t border border-amber-400/30"
                style={{ bottom: `${(f.low / max) * 100}%`, height: `${((f.high - f.low) / max) * 100}%` }}
              />
              {/* Predicted */}
              <div
                className="relative w-full rounded-t bg-gradient-to-t from-amber-500/70 to-amber-400 hover:from-amber-400 hover:to-amber-300 transition-all"
                style={{ height: `${(f.predicted / max) * 100}%` }}
              >
                <span className="absolute -top-5 left-1/2 -translate-x-1/2 text-[9px] font-mono opacity-0 group-hover:opacity-100 transition bg-background px-1 py-0.5 rounded">
                  {formatCompact(f.predicted)}
                </span>
              </div>
            </div>
            <span className="text-[8px] text-muted-foreground text-center leading-tight">{f.m}</span>
            <span className="text-[8px] text-amber-400 font-mono">{Math.round(f.confidence * 100)}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function AnalyticsTable() {
  return (
    <div className="glass rounded-2xl p-5">
      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="text-sm font-semibold flex items-center gap-2">
            <Icon name="pie" className="w-4 h-4 text-emerald-400" />
            تحليلات الفروع
          </h3>
          <p className="text-[10px] text-muted-foreground">ملخص الأداء المالي لكل فرع</p>
        </div>
        <button className="text-[10px] px-2 py-1 rounded-lg glass hover:bg-white/10 transition flex items-center gap-1">
          <Icon name="download" className="w-3 h-3" />
          تصدير
        </button>
      </div>
      <div className="overflow-x-auto -mx-2 scroll-thin">
        <table className="w-full text-xs">
          <thead>
            <tr className="text-muted-foreground border-b border-white/5">
              <th className="text-right font-medium py-2 px-2">الفرع</th>
              <th className="text-left font-medium py-2 px-2">المبيعات</th>
              <th className="text-left font-medium py-2 px-2">المشتريات</th>
              <th className="text-left font-medium py-2 px-2">المصروفات</th>
              <th className="text-left font-medium py-2 px-2">الخزينة</th>
              <th className="text-left font-medium py-2 px-2">الإجمالي</th>
            </tr>
          </thead>
          <tbody>
            {BRANCH_ANALYTICS.map((row, i) => (
              <tr key={i} className="border-b border-white/5 hover:bg-white/[0.02] transition cursor-pointer">
                <td className="py-2.5 px-2 font-medium flex items-center gap-1.5">
                  <Icon name="building" className="w-3 h-3 text-muted-foreground" />
                  {row.branch}
                </td>
                <td className="py-2.5 px-2 text-left num text-emerald-400">{formatCurrency(row.sales)}</td>
                <td className="py-2.5 px-2 text-left num text-amber-400">{formatCurrency(row.purchases)}</td>
                <td className="py-2.5 px-2 text-left num text-pink-400">{formatCurrency(row.expenses)}</td>
                <td className="py-2.5 px-2 text-left num text-teal-400">{formatCurrency(row.treasury)}</td>
                <td className="py-2.5 px-2 text-left num font-bold">{formatCurrency(row.total)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function RecentInvoices() {
  const statusMap: Record<string, { label: string; cls: string }> = {
    paid: { label: "مدفوعة", cls: "bg-emerald-500/15 text-emerald-400" },
    pending: { label: "معلقة", cls: "bg-amber-500/15 text-amber-400" },
    overdue: { label: "متأخرة", cls: "bg-red-500/15 text-red-400" },
  };
  return (
    <div className="glass rounded-2xl p-5">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <Icon name="file-text" className="w-4 h-4 text-emerald-400" />
          آخر الفواتير
        </h3>
        <button className="text-[10px] text-emerald-400 hover:underline">عرض الكل</button>
      </div>
      <div className="space-y-1.5">
        {RECENT_INVOICES.map((inv) => {
          const s = statusMap[inv.status];
          return (
            <div key={inv.id} className="flex items-center justify-between gap-2 p-2.5 rounded-lg hover:bg-white/5 transition group">
              <div className="flex items-center gap-2.5 min-w-0">
                <div className="w-7 h-7 rounded-lg bg-emerald-500/10 flex items-center justify-center shrink-0">
                  <Icon name="file-text" className="w-3.5 h-3.5 text-emerald-400" />
                </div>
                <div className="min-w-0">
                  <div className="text-xs font-medium truncate">{inv.customer}</div>
                  <div className="text-[9px] text-muted-foreground num">{inv.id} · {inv.date}</div>
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <div className="hidden sm:flex items-center gap-1 text-[9px] text-amber-400">
                  <Icon name="brain" className="w-2.5 h-2.5" />
                  <span className="num">{Math.round(inv.aiScore * 100)}%</span>
                </div>
                <span className={`text-[10px] px-2 py-0.5 rounded-full ${s.cls}`}>{s.label}</span>
                <div className="text-xs font-bold num w-16 text-left">{formatCurrency(inv.amount)}</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

function AIInsights() {
  return (
    <div className="glass rounded-2xl p-5">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <Icon name="sparkles" className="w-4 h-4 text-amber-400" />
          رؤى ذكاء اصطناعي
        </h3>
        <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-400 flex items-center gap-0.5">
          <span className="w-1 h-1 bg-emerald-400 rounded-full pulse-glow" />
          مباشر
        </span>
      </div>
      <div className="space-y-2 max-h-72 overflow-y-auto scroll-thin -mx-1 px-1">
        {AI_INSIGHTS.map((ins) => (
          <div
            key={ins.id}
            className={`p-2.5 rounded-xl border transition cursor-pointer hover:scale-[1.01] ${
              ins.severity === "warning" ? "border-amber-500/20 bg-amber-500/5" :
              ins.severity === "success" ? "border-emerald-500/20 bg-emerald-500/5" :
              "border-pink-500/20 bg-pink-500/5"
            }`}
          >
            <div className="flex items-start justify-between gap-2 mb-1">
              <div className="flex items-center gap-1.5 min-w-0">
                <Icon
                  name={ins.severity === "warning" ? "alert-triangle" : ins.severity === "success" ? "check-circle" : "info"}
                  className={`w-3.5 h-3.5 shrink-0 ${
                    ins.severity === "warning" ? "text-amber-400" :
                    ins.severity === "success" ? "text-emerald-400" : "text-pink-400"
                  }`}
                />
                <span className="text-[11px] font-semibold truncate">{ins.title}</span>
              </div>
              <span className="text-[8px] px-1 py-0.5 rounded bg-white/5 text-muted-foreground shrink-0">{ins.tag}</span>
            </div>
            <p className="text-[10px] text-muted-foreground leading-relaxed mb-1.5">{ins.body}</p>
            <div className="flex items-center gap-1">
              <div className="flex-1 h-0.5 rounded-full bg-muted overflow-hidden">
                <div
                  className={`h-full ${
                    ins.confidence >= 0.9 ? "bg-emerald-400" :
                    ins.confidence >= 0.8 ? "bg-amber-400" : "bg-pink-400"
                  }`}
                  style={{ width: `${ins.confidence * 100}%` }}
                />
              </div>
              <span className="text-[9px] text-muted-foreground num">دقة {Math.round(ins.confidence * 100)}%</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function BlockchainTrail() {
  return (
    <div className="glass rounded-2xl p-5">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold flex items-center gap-2">
          <Icon name="shield" className="w-4 h-4 text-emerald-400" />
          سجل التدقيق الكتلي
        </h3>
        <span className="text-[9px] px-1.5 py-0.5 rounded bg-emerald-500/15 text-emerald-400 border border-emerald-500/20">
          موثّق
        </span>
      </div>
      <div className="space-y-1">
        {BLOCKCHAIN_LEDGER.slice(0, 5).map((b, i) => (
          <div key={b.hash} className="flex items-center gap-2 p-2 rounded-lg hover:bg-white/5 transition group">
            <div className="flex flex-col items-center gap-0.5 shrink-0">
              <div className="w-5 h-5 rounded bg-emerald-500/10 flex items-center justify-center">
                <Icon name="hexagon" className="w-3 h-3 text-emerald-400" />
              </div>
              {i < 4 && <div className="w-px h-3 bg-emerald-500/20" />}
            </div>
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-1">
                <span className="text-[11px] font-medium">{b.type}</span>
                <span className="text-[9px] text-muted-foreground num">{b.ts}</span>
              </div>
              <div className="flex items-center justify-between gap-1">
                <span className="text-[9px] text-muted-foreground font-mono">{b.hash}</span>
                {b.amount > 0 && <span className="text-[9px] text-emerald-400 num">{formatCompact(b.amount)}</span>}
              </div>
            </div>
          </div>
        ))}
      </div>
      <button className="w-full mt-2 py-1.5 text-[10px] text-emerald-400 hover:bg-emerald-500/10 rounded-lg transition">
        عرض السلسلة الكاملة ←
      </button>
    </div>
  );
}
