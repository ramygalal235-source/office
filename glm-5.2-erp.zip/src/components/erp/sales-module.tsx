"use client";
import { useState } from "react";
import { Icon } from "./icons";
import { INVENTORY_ITEMS, CUSTOMERS, formatCurrency } from "@/lib/erp-data";
import { toast } from "sonner";

type LineItem = {
  id: string;
  code: string;
  name: string;
  unit: string;
  price: number;
  qty: number;
  aiDemand: number;
};

export function SalesModule() {
  const [customer, setCustomer] = useState("");
  const [items, setItems] = useState<LineItem[]>([]);
  const [aiPricing, setAiPricing] = useState(true);
  const [generating, setGenerating] = useState(false);

  const subtotal = items.reduce((s, i) => s + i.price * i.qty, 0);
  const discount = aiPricing ? subtotal * 0.05 : 0;
  const tax = (subtotal - discount) * 0.14;
  const total = subtotal - discount + tax;

  function addItem(inv: typeof INVENTORY_ITEMS[number]) {
    if (items.some((i) => i.code === inv.code)) {
      return toast.error("الصنف مضاف مسبقاً");
    }
    setItems((prev) => [
      ...prev,
      {
        id: Date.now() + inv.code,
        code: inv.code,
        name: inv.name,
        unit: inv.unit,
        price: inv.price,
        qty: 1,
        aiDemand: inv.aiDemand,
      },
    ]);
    toast.success(`تمت إضافة ${inv.name}`);
  }

  function updateQty(id: string, delta: number) {
    setItems((prev) =>
      prev.map((i) => (i.id === id ? { ...i, qty: Math.max(1, i.qty + delta) } : i))
    );
  }

  function removeItem(id: string) {
    setItems((prev) => prev.filter((i) => i.id !== id));
  }

  function aiGenerate() {
    setGenerating(true);
    setTimeout(() => {
      // AI suggests 3 items based on customer history
      const picks = INVENTORY_ITEMS.slice(0, 3).map((inv) => ({
        id: Date.now() + inv.code + Math.random(),
        code: inv.code,
        name: inv.name,
        unit: inv.unit,
        price: inv.price,
        qty: Math.ceil(Math.random() * 3),
        aiDemand: inv.aiDemand,
      }));
      setItems(picks);
      setGenerating(false);
      toast.success("GLM 5.2 اقترح 3 أصناف بناءً على نمط العميل", {
        description: "دقة الاقتراح: 91%",
      });
    }, 1400);
  }

  function save() {
    if (!customer) return toast.error("اختر العميل أولاً");
    if (!items.length) return toast.error("أضف أصنافاً للفاتورة");
    toast.success("تم حفظ الفاتورة بنجاح", {
      description: `الإجمالي: ${formatCurrency(total)} ج.م · مسجّلة في السجل الكتلي`,
    });
    setItems([]);
    setCustomer("");
  }

  return (
    <div className="space-y-5">
      {/* Title */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold">المبيعات</h1>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-emerald-500/15 text-emerald-400 border border-emerald-500/20 flex items-center gap-1">
              <Icon name="brain" className="w-2.5 h-2.5" />
              فاتورة ذكية
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">إنشاء فاتورة بمساعدة الذكاء الاصطناعي والتسعير التنبؤي</p>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={aiGenerate}
            disabled={generating}
            className="px-3 py-2 rounded-xl bg-gradient-to-r from-amber-500/20 to-emerald-500/20 border border-emerald-500/30 text-xs font-medium hover:border-emerald-500/50 transition flex items-center gap-1.5"
          >
            <Icon name="sparkles" className={`w-3.5 h-3.5 text-emerald-400 ${generating ? "animate-spin" : ""}`} />
            {generating ? "جارٍ التوليد..." : "توليد بالذكاء الاصطناعي"}
          </button>
          <button
            onClick={save}
            className="px-3 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 text-black text-xs font-semibold hover:from-emerald-400 hover:to-emerald-500 transition flex items-center gap-1.5"
          >
            <Icon name="save" className="w-3.5 h-3.5" />
            حفظ الفاتورة
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        {/* Left — Form */}
        <div className="xl:col-span-2 space-y-5">
          {/* Customer */}
          <div className="glass rounded-2xl p-5 space-y-3">
            <h3 className="text-sm font-semibold flex items-center gap-2">
              <Icon name="user" className="w-4 h-4 text-emerald-400" />
              البيانات الرئيسية
            </h3>
            <div className="grid sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] text-muted-foreground mb-1 block">العميل</label>
                <div className="relative">
                  <select
                    value={customer}
                    onChange={(e) => setCustomer(e.target.value)}
                    className="w-full appearance-none bg-input/40 border border-border/40 rounded-xl px-3 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-primary/30"
                  >
                    <option value="">اختر العميل</option>
                    {CUSTOMERS.map((c) => (
                      <option key={c.id} value={c.id}>
                        {c.name} — تصنيف {c.rating}
                      </option>
                    ))}
                  </select>
                  <Icon name="chevron-down" className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                </div>
              </div>
              <div>
                <label className="text-[10px] text-muted-foreground mb-1 block">نوع الفاتورة</label>
                <div className="relative">
                  <select className="w-full appearance-none bg-input/40 border border-border/40 rounded-xl px-3 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-primary/30">
                    <option>نقدية</option>
                    <option>آجل</option>
                    <option>فيزا</option>
                  </select>
                  <Icon name="chevron-down" className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                </div>
              </div>
            </div>

            {/* AI customer insight */}
            {customer && (
              <div className="rounded-xl border border-emerald-500/20 bg-emerald-500/5 p-2.5 float-up">
                <div className="flex items-center gap-2 mb-1">
                  <Icon name="brain" className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-[11px] font-semibold text-emerald-300">تحليل العميل</span>
                </div>
                <p className="text-[10px] text-muted-foreground leading-relaxed">
                  {(() => {
                    const c = CUSTOMERS.find((x) => x.id === customer);
                    return c
                      ? `تصنيف الائتمان: ${c.rating} · مخاطرة الذكاء الاصطناعي: ${Math.round(c.aiRisk * 100)}% · الحد الائتماني المتاح: ${formatCurrency(c.creditLimit - c.balance)} ج.م`
                      : "";
                  })()}
                </p>
              </div>
            )}
          </div>

          {/* Invoice items */}
          <div className="glass rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-sm font-semibold flex items-center gap-2">
                <Icon name="shopping-cart" className="w-4 h-4 text-emerald-400" />
                أصناف الفاتورة
              </h3>
              <label className="flex items-center gap-2 text-[10px] cursor-pointer">
                <input
                  type="checkbox"
                  checked={aiPricing}
                  onChange={(e) => setAiPricing(e.target.checked)}
                  className="accent-emerald-500"
                />
                <span className="flex items-center gap-1">
                  <Icon name="tag" className="w-3 h-3 text-amber-400" />
                  تسعير ذكي
                </span>
              </label>
            </div>

            {items.length > 0 ? (
              <div className="space-y-1.5">
                {items.map((it) => (
                  <div key={it.id} className="flex items-center gap-2 p-2 rounded-lg bg-white/[0.02] hover:bg-white/5 transition group">
                    <div className="flex-1 min-w-0">
                      <div className="text-xs font-medium truncate">{it.name}</div>
                      <div className="text-[9px] text-muted-foreground num">{it.code} · {formatCurrency(it.price)} ج.م</div>
                    </div>
                    <div className="flex items-center gap-1 shrink-0">
                      <button onClick={() => updateQty(it.id, -1)} className="w-6 h-6 rounded-md bg-muted/50 hover:bg-muted text-xs">−</button>
                      <span className="text-xs font-mono w-6 text-center num">{it.qty}</span>
                      <button onClick={() => updateQty(it.id, 1)} className="w-6 h-6 rounded-md bg-muted/50 hover:bg-muted text-xs">+</button>
                    </div>
                    <div className="text-xs font-bold num w-20 text-left">{formatCurrency(it.price * it.qty)}</div>
                    <button
                      onClick={() => removeItem(it.id)}
                      className="p-1.5 rounded-md text-red-400 hover:bg-red-500/10 transition opacity-0 group-hover:opacity-100"
                      aria-label="حذف"
                    >
                      <Icon name="trash" className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-xs text-muted-foreground">
                <Icon name="shopping-cart" className="w-8 h-8 mx-auto mb-2 opacity-30" />
                <div>لم تتم إضافة أصناف بعد</div>
                <div className="text-[10px] mt-1">اختر من القائمة بالأسفل أو استخدم التوليد الذكي</div>
              </div>
            )}
          </div>

          {/* Inventory picker */}
          <div className="glass rounded-2xl p-5">
            <h3 className="text-sm font-semibold flex items-center gap-2 mb-3">
              <Icon name="boxes" className="w-4 h-4 text-emerald-400" />
              المخزون المتاح
              <span className="text-[9px] text-muted-foreground">(انقر للإضافة)</span>
            </h3>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-2">
              {INVENTORY_ITEMS.map((inv) => (
                <button
                  key={inv.code}
                  onClick={() => addItem(inv)}
                  className="text-right p-2.5 rounded-xl border border-white/5 hover:border-emerald-500/30 hover:bg-emerald-500/5 transition group"
                >
                  <div className="flex items-center justify-between gap-1 mb-1">
                    <span className="text-[11px] font-medium truncate">{inv.name}</span>
                    <span className="text-[9px] text-emerald-400 flex items-center gap-0.5 shrink-0">
                      <Icon name="brain" className="w-2.5 h-2.5" />
                      {Math.round(inv.aiDemand * 100)}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[9px] text-muted-foreground">
                    <span className="num">{inv.code}</span>
                    <span className="num">{formatCurrency(inv.price)} ج.م</span>
                  </div>
                  <div className="text-[9px] text-muted-foreground mt-0.5">المخزون: <span className="num">{inv.stock}</span> {inv.unit}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right — Totals */}
        <div className="space-y-5">
          <div className="glass rounded-2xl p-5 sticky top-20">
            <h3 className="text-sm font-semibold flex items-center gap-2 mb-4">
              <Icon name="wallet" className="w-4 h-4 text-emerald-400" />
              ملخص الفاتورة
            </h3>

            <div className="space-y-2 text-xs">
              <div className="flex justify-between py-2 border-b border-white/5">
                <span className="text-muted-foreground">الإجمالي الفرعي</span>
                <span className="num font-medium">{formatCurrency(subtotal)} ج.م</span>
              </div>
              <div className="flex justify-between py-2 border-b border-white/5">
                <span className="text-muted-foreground flex items-center gap-1">
                  خصم ذكي
                  {aiPricing && <span className="text-[9px] text-amber-400">(5%)</span>}
                </span>
                <span className="num text-amber-400">−{formatCurrency(discount)}</span>
              </div>
              <div className="flex justify-between py-2 border-b border-white/5">
                <span className="text-muted-foreground">ضريبة القيمة المضافة (14%)</span>
                <span className="num">{formatCurrency(tax)}</span>
              </div>
              <div className="flex justify-between py-3">
                <span className="font-semibold">الإجمالي النهائي</span>
                <span className="num font-bold text-lg gradient-text">{formatCurrency(total)}</span>
              </div>
              <div className="text-[9px] text-muted-foreground text-left">ج.م</div>
            </div>

            <div className="mt-4 p-3 rounded-xl bg-emerald-500/5 border border-emerald-500/20 space-y-1.5">
              <div className="text-[10px] font-semibold text-emerald-300 flex items-center gap-1">
                <Icon name="brain" className="w-3 h-3" />
                توصية الذكاء الاصطناعي
              </div>
              <p className="text-[10px] text-muted-foreground leading-relaxed">
                {items.length === 0
                  ? "ابدأ بإضافة أصناف أو استخدم التوليد الذكي لتوصيات مخصصة للعميل."
                  : aiPricing
                  ? "تطبيق خصم 5% يرفع احتمالية إتمام الطلب بنسبة 18% — موصى به."
                  : "العميل مؤهل لخصم 5% — فعّل التسعير الذكي لزيادة هامش الرضا."}
              </p>
            </div>

            <div className="mt-4 grid grid-cols-2 gap-2">
              <button
                onClick={() => { setItems([]); setCustomer(""); toast.info("تم مسح الفاتورة"); }}
                className="px-3 py-2 rounded-xl border border-white/10 text-xs hover:bg-white/5 transition flex items-center justify-center gap-1.5"
              >
                <Icon name="trash" className="w-3.5 h-3.5" />
                مسح
              </button>
              <button
                onClick={save}
                className="px-3 py-2 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 text-black text-xs font-semibold hover:from-emerald-400 hover:to-emerald-500 transition flex items-center justify-center gap-1.5"
              >
                <Icon name="save" className="w-3.5 h-3.5" />
                حفظ
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
