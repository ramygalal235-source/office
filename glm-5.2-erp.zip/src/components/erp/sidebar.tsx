"use client";
import { Icon } from "./icons";

export type ModuleKey =
  | "dashboard"
  | "system"
  | "opening"
  | "assets"
  | "sales"
  | "purchases"
  | "warehouses"
  | "treasury"
  | "banks"
  | "settlements"
  | "reports"
  | "calendar"
  | "settings"
  | "nobel";

export const MODULES: Array<{ key: ModuleKey; label: string; icon: string; badge?: string }> = [
  { key: "dashboard", label: "الرئيسية", icon: "dashboard" },
  { key: "sales", label: "المبيعات", icon: "trending-up", badge: "AI" },
  { key: "purchases", label: "المشتريات", icon: "shopping-cart" },
  { key: "warehouses", label: "المخازن", icon: "boxes", badge: "IoT" },
  { key: "treasury", label: "الخزينة", icon: "wallet" },
  { key: "banks", label: "البنوك والشيكات", icon: "banknote" },
  { key: "settlements", label: "التسويات", icon: "list" },
  { key: "reports", label: "التقارير", icon: "pie", badge: "AI" },
  { key: "calendar", label: "التقويم", icon: "calendar" },
  { key: "system", label: "تعريف النظام", icon: "settings" },
  { key: "opening", label: "الأرصدة الافتتاحية", icon: "file-text" },
  { key: "assets", label: "الأصول الثابتة", icon: "building" },
  { key: "nobel", label: "خطة نوبل", icon: "award", badge: "★" },
  { key: "settings", label: "إعدادات البرنامج", icon: "settings" },
];

type Props = {
  active: ModuleKey;
  onNavigate: (key: ModuleKey) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
};

export function Sidebar({ active, onNavigate, collapsed, onToggleCollapse }: Props) {
  return (
    <aside
      className={`${collapsed ? "w-[72px]" : "w-[260px]"} shrink-0 transition-all duration-300 flex flex-col border-l border-white/5 bg-sidebar/60 backdrop-blur-xl sticky top-0 h-screen z-30`}
    >
      {/* Brand */}
      <div className="h-16 flex items-center justify-between px-4 border-b border-white/5">
        <div className={`flex items-center gap-2.5 ${collapsed ? "justify-center w-full" : ""}`}>
          <div className="relative shrink-0">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center">
              <Icon name="atom" className="w-5 h-5 text-black" />
            </div>
            <div className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-emerald-400 rounded-full pulse-glow" />
          </div>
          {!collapsed && (
            <div className="leading-tight">
              <div className="text-sm font-bold">GLM <span className="gradient-text">5.2</span></div>
              <div className="text-[10px] text-muted-foreground">ERP · Nobel Edition</div>
            </div>
          )}
        </div>
        {!collapsed && (
          <button
            onClick={onToggleCollapse}
            className="text-muted-foreground hover:text-foreground transition p-1 rounded-md hover:bg-white/5"
            aria-label="طي القائمة"
          >
            <Icon name="chevron-right" className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* Collapse toggle when collapsed */}
      {collapsed && (
        <button
          onClick={onToggleCollapse}
          className="mx-auto mt-2 text-muted-foreground hover:text-foreground transition p-1.5 rounded-md hover:bg-white/5"
          aria-label="توسيع القائمة"
        >
          <Icon name="chevron-left" className="w-4 h-4" />
        </button>
      )}

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto no-scrollbar py-3 px-2.5 space-y-0.5 scroll-thin">
        {MODULES.map((m) => {
          const isActive = active === m.key;
          return (
            <button
              key={m.key}
              onClick={() => onNavigate(m.key)}
              title={collapsed ? m.label : undefined}
              className={`w-full flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-sm transition-all relative group
                ${isActive
                  ? "bg-primary/15 text-primary"
                  : "text-muted-foreground hover:bg-white/5 hover:text-foreground"
                }
                ${collapsed ? "justify-center" : ""}`}
            >
              {isActive && (
                <span className="absolute right-0 top-1/2 -translate-y-1/2 w-1 h-5 bg-primary rounded-l-full" />
              )}
              <Icon name={m.icon} className={`w-4 h-4 shrink-0 ${isActive ? "text-primary" : ""}`} />
              {!collapsed && <span className="flex-1 text-right truncate">{m.label}</span>}
              {!collapsed && m.badge && (
                <span className="text-[9px] font-bold px-1.5 py-0.5 rounded-md bg-primary/20 text-primary">
                  {m.badge}
                </span>
              )}
              {collapsed && m.badge && (
                <span className="absolute -top-0.5 -left-0.5 w-3.5 h-3.5 rounded-full bg-primary text-[8px] font-bold flex items-center justify-center text-black">
                  {m.badge}
                </span>
              )}
            </button>
          );
        })}
      </nav>

      {/* Footer status */}
      {!collapsed && (
        <div className="p-3 border-t border-white/5">
          <div className="glass rounded-xl p-3 space-y-2">
            <div className="flex items-center justify-between text-[10px]">
              <span className="text-muted-foreground">حالة النظام</span>
              <span className="flex items-center gap-1 text-emerald-400">
                <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full pulse-glow" />
                نشط
              </span>
            </div>
            <div className="flex items-center justify-between text-[10px]">
              <span className="text-muted-foreground">محرك الذكاء</span>
              <span className="text-emerald-400 font-medium">GLM 5.2 · 12ms</span>
            </div>
            <div className="flex items-center justify-between text-[10px]">
              <span className="text-muted-foreground">السجل الكتلي</span>
              <span className="text-amber-400 font-medium">1.84M بلوك</span>
            </div>
          </div>
        </div>
      )}
    </aside>
  );
}
