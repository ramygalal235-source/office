"use client";
import { useEffect, useRef, useState } from "react";
import { Icon } from "./icons";
import { AI_PROMPTS, AI_INSIGHTS } from "@/lib/erp-data";
import { toast } from "sonner";

type Msg = { id: string; role: "user" | "ai"; content: string; chart?: "forecast" | "risk" };

type Props = {
  open: boolean;
  onClose: () => void;
};

const CANNED_RESPONSES: Record<string, { text: string; chart?: "forecast" | "risk" }> = {
  default: {
    text: "حلّلت البيانات عبر نموذج GLM 5.2 (32 طبقة). إليك ما رصدته:\n\n• إجمالي المبيعات اليوم: 4.87M ج.م (+12.4%)\n• السيولة النقدية: 2.04M ج.م (+8.1%)\n• 5 تنبيهات نشطة، أهمها فاتورة مكررة محتملة بقيمة 84,500 ج.م\n\nهل تريد تفاصيلاً أكثر عن أي بند؟",
  },
  forecast: {
    text: "توقع محرك التنبؤ الكمي لمبيعات الـ 6 أشهر القادمة:\n\n• يناير 2027: 612K ج.م (دقة 94%)\n• فبراير 2027: 648K ج.م (دقة 91%)\n• مارس 2027: 672K ج.م (دقة 88%)\n• أبريل 2027: 695K ج.م (دقة 85%)\n\nالنمو المتوقع: +18.4% مقارنة بالعام السابق. التوصية: زيادة المخزون بنسبة 25% قبل 15 يونيو.",
    chart: "forecast",
  },
  risk: {
    text: "تحليل مخاطر العملاء (شبكة GNN):\n\n🔴 متاجر كايرو — مخاطرة عالية (62%)\n   ذمة متأخرة: 18,700 ج.م منذ 19 يونيو\n🟡 مؤسسة الأهرام — مخاطرة متوسطة (28%)\n🟢 شركة النيل — مخاطرة منخفضة (12%)\n🟢 شركة سفنكس — مخاطرة منخفضة (8%)\n\nالتوصية: تفعيل تحصيل آلي لمتجري كايرو خلال 48 ساعة.",
    chart: "risk",
  },
};

export function AICopilot({ open, onClose }: Props) {
  const [messages, setMessages] = useState<Msg[]>([
    {
      id: "intro",
      role: "ai",
      content: "مرحباً 👋 أنا GLM 5.2 — مساعدك الذكي. أستطيع تحليل البيانات، التنبؤ بالتدفقات، كشف الاحتيال، واقتراح تحسينات. كيف أساعدك اليوم؟",
    },
  ]);
  const [input, setInput] = useState("");
  const [thinking, setThinking] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, thinking]);

  // Focus input when opened
  useEffect(() => {
    if (open) {
      const t = setTimeout(() => inputRef.current?.focus(), 300);
      return () => clearTimeout(t);
    }
  }, [open]);

  // Close on Escape
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  // Lock body scroll when open
  useEffect(() => {
    if (open) {
      const prev = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => { document.body.style.overflow = prev; };
    }
  }, [open]);

  function send(text: string) {
    if (!text.trim()) return;
    const userMsg: Msg = { id: Date.now() + "u", role: "user", content: text };
    setMessages((m) => [...m, userMsg]);
    setInput("");
    setThinking(true);

    const lower = text.toLowerCase();
    let key: keyof typeof CANNED_RESPONSES = "default";
    if (lower.includes("توقع") || lower.includes("تنبؤ") || lower.includes("مبيعات") || lower.includes("نقدي")) key = "forecast";
    else if (lower.includes("مخاطر") || lower.includes("عملاء") || lower.includes("احتيال") || lower.includes("خطر")) key = "risk";

    setTimeout(() => {
      const r = CANNED_RESPONSES[key] ?? CANNED_RESPONSES.default;
      setMessages((m) => [...m, { id: Date.now() + "a", role: "ai", content: r.text, chart: r.chart }]);
      setThinking(false);
    }, 1300);
  }

  return (
    <>
      {/* Backdrop — pointer-events-none so it never blocks adjacent UI; only used for visual dimming */}
      <div
        className={`fixed inset-0 bg-black/40 backdrop-blur-sm z-40 transition-opacity ${open ? "opacity-100" : "opacity-0 pointer-events-none"}`}
        onClick={onClose}
        aria-hidden="true"
      />

      {/* Panel */}
      <div
        role="dialog"
        aria-modal="true"
        aria-label="مساعد GLM 5.2 الذكي"
        className={`fixed top-0 left-0 bottom-0 w-full max-w-md z-50 transition-transform duration-300 ${open ? "translate-x-0" : "-translate-x-full"}`}
      >
        <div className="h-full glass-strong border-r border-border/60 flex flex-col">
          {/* Header */}
          <div className="h-16 px-4 flex items-center justify-between border-b border-border/40 shrink-0">
            <div className="flex items-center gap-2.5">
              <div className="relative">
                <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-amber-500 flex items-center justify-center">
                  <Icon name="bot" className="w-5 h-5 text-white" />
                </div>
                <span className="absolute -top-0.5 -right-0.5 w-2.5 h-2.5 bg-emerald-500 rounded-full border-2 border-background pulse-glow" />
              </div>
              <div className="leading-tight">
                <div className="text-sm font-semibold">GLM 5.2 Co-pilot</div>
                <div className="text-[10px] text-emerald-500 flex items-center gap-1">
                  <span className="w-1 h-1 bg-emerald-500 rounded-full" />
                  متصل · 12ms
                </div>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 rounded-lg hover:bg-foreground/5 text-muted-foreground hover:text-foreground transition"
              aria-label="إغلاق"
            >
              <Icon name="x" className="w-4 h-4" />
            </button>
          </div>

          {/* Insights strip */}
          <div className="px-4 py-2.5 border-b border-border/30 shrink-0">
            <div className="text-[10px] text-muted-foreground mb-1.5 flex items-center gap-1">
              <Icon name="sparkles" className="w-3 h-3 text-amber-500" />
              رؤى مباشرة
            </div>
            <div className="flex gap-1.5 overflow-x-auto no-scrollbar">
              {AI_INSIGHTS.slice(0, 3).map((i) => (
                <button
                  key={i.id}
                  onClick={() => send(i.body)}
                  className={`shrink-0 px-2 py-1 rounded-md text-[10px] border transition hover:scale-105 ${
                    i.severity === "warning" ? "border-amber-500/30 text-amber-600 dark:text-amber-300 bg-amber-500/5" :
                    i.severity === "success" ? "border-emerald-500/30 text-emerald-600 dark:text-emerald-300 bg-emerald-500/5" :
                    "border-pink-500/30 text-pink-600 dark:text-pink-300 bg-pink-500/5"
                  }`}
                >
                  {i.tag}
                </button>
              ))}
            </div>
          </div>

          {/* Messages */}
          <div ref={scrollRef} className="flex-1 overflow-y-auto px-4 py-4 space-y-4 scroll-thin">
            {messages.map((m) => (
              <div key={m.id} className={`flex gap-2.5 ${m.role === "user" ? "flex-row-reverse" : ""} float-up`}>
                <div className={`w-7 h-7 rounded-lg shrink-0 flex items-center justify-center ${
                  m.role === "user" ? "bg-muted" : "bg-gradient-to-br from-emerald-500 to-amber-500"
                }`}>
                  <Icon name={m.role === "user" ? "user" : "bot"} className={`w-3.5 h-3.5 ${m.role === "user" ? "text-foreground" : "text-white"}`} />
                </div>
                <div className={`max-w-[85%] ${m.role === "user" ? "items-end" : "items-start"} flex flex-col gap-2`}>
                  <div className={`px-3 py-2 rounded-2xl text-xs leading-relaxed whitespace-pre-line ${
                    m.role === "user" ? "bg-muted rounded-tr-sm" : "glass rounded-tl-sm"
                  }`}>
                    {m.content}
                  </div>
                  {m.chart === "forecast" && <MiniForecastChart />}
                  {m.chart === "risk" && <MiniRiskChart />}
                </div>
              </div>
            ))}
            {thinking && (
              <div className="flex gap-2.5 float-up">
                <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-emerald-500 to-amber-500 flex items-center justify-center shrink-0">
                  <Icon name="bot" className="w-3.5 h-3.5 text-white" />
                </div>
                <div className="px-3 py-2.5 rounded-2xl glass rounded-tl-sm flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-primary rounded-full pulse-glow" style={{ animationDelay: "0ms" }} />
                  <span className="w-1.5 h-1.5 bg-primary rounded-full pulse-glow" style={{ animationDelay: "200ms" }} />
                  <span className="w-1.5 h-1.5 bg-primary rounded-full pulse-glow" style={{ animationDelay: "400ms" }} />
                  <span className="text-[10px] text-muted-foreground mr-1">يفكّر...</span>
                </div>
              </div>
            )}
          </div>

          {/* Suggested prompts */}
          {messages.length <= 1 && (
            <div className="px-4 pb-2 shrink-0">
              <div className="text-[10px] text-muted-foreground mb-1.5">جرّب أن تسأل:</div>
              <div className="flex flex-wrap gap-1.5">
                {AI_PROMPTS.slice(0, 4).map((p) => (
                  <button
                    key={p}
                    onClick={() => send(p)}
                    className="px-2.5 py-1 rounded-full text-[10px] border border-primary/30 text-primary bg-primary/5 hover:bg-primary/15 transition"
                  >
                    {p}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Input */}
          <div className="p-3 border-t border-border/40 shrink-0">
            <form
              onSubmit={(e) => { e.preventDefault(); send(input); }}
              className="flex items-center gap-2"
            >
              <button
                type="button"
                onClick={() => toast.info("البحث الصوتي قيد التطوير")}
                className="p-2.5 rounded-xl text-muted-foreground hover:text-foreground hover:bg-foreground/5 transition"
                aria-label="إدخال صوتي"
              >
                <Icon name="mic" className="w-4 h-4" />
              </button>
              <input
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="اكتب سؤالك..."
                className="flex-1 bg-input/40 border border-border/40 rounded-xl px-3 py-2.5 text-xs focus:outline-none focus:ring-2 focus:ring-primary/30"
              />
              <button
                type="submit"
                disabled={!input.trim()}
                className="p-2.5 rounded-xl bg-gradient-to-br from-emerald-500 to-emerald-600 text-white hover:from-emerald-400 hover:to-emerald-500 transition disabled:opacity-40 disabled:cursor-not-allowed shadow-lg shadow-emerald-500/20"
                aria-label="إرسال"
              >
                <Icon name="send" className="w-4 h-4" />
              </button>
            </form>
            <div className="text-[9px] text-muted-foreground/60 text-center mt-1.5">
              GLM 5.2 · قد يقدّم معلومات غير دقيقة — راجع البيانات الحرجة
            </div>
          </div>
        </div>
      </div>
    </>
  );
}

function MiniForecastChart() {
  const data = [612, 648, 672, 695, 718, 745];
  const max = Math.max(...data);
  return (
    <div className="w-full glass rounded-xl p-2.5 space-y-1.5">
      <div className="text-[9px] text-muted-foreground">توقعات المبيعات (K ج.م)</div>
      <div className="flex items-end justify-between gap-1 h-16">
        {data.map((v, i) => (
          <div key={i} className="flex-1 flex flex-col items-center gap-1">
            <div
              className="w-full rounded-t bg-gradient-to-t from-primary/40 to-primary transition-all hover:from-primary/60 hover:to-primary"
              style={{ height: `${(v / max) * 100}%` }}
            />
            <span className="text-[8px] text-muted-foreground num">{v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function MiniRiskChart() {
  const customers = [
    { name: "كايرو", risk: 62, color: "bg-red-500" },
    { name: "أهرام", risk: 28, color: "bg-amber-500" },
    { name: "النيل", risk: 12, color: "bg-emerald-500" },
    { name: "سفنكس", risk: 8, color: "bg-emerald-500" },
  ];
  return (
    <div className="w-full glass rounded-xl p-2.5 space-y-1.5">
      <div className="text-[9px] text-muted-foreground">مخاطر العملاء (%)</div>
      <div className="space-y-1">
        {customers.map((c) => (
          <div key={c.name} className="flex items-center gap-2">
            <span className="text-[9px] w-10 shrink-0">{c.name}</span>
            <div className="flex-1 h-1.5 rounded-full bg-muted overflow-hidden">
              <div className={`h-full ${c.color}`} style={{ width: `${c.risk}%` }} />
            </div>
            <span className="text-[9px] num w-6 text-end">{c.risk}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}
