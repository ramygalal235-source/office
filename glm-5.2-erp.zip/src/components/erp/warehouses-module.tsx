"use client";
import { useState, useEffect } from "react";
import { Icon } from "./icons";
import { WAREHOUSES, formatCurrency } from "@/lib/erp-data";
import { toast } from "sonner";

export function WarehousesModule() {
  const [selected, setSelected] = useState(WAREHOUSES[0].id);
  const [liveData, setLiveData] = useState(WAREHOUSES);

  // Simulate IoT telemetry
  useEffect(() => {
    const t = setInterval(() => {
      setLiveData((prev) =>
        prev.map((w) => ({
          ...w,
          temp: +(w.temp + (Math.random() - 0.5) * 0.4).toFixed(1),
          humidity: Math.max(20, Math.min(80, w.humidity + Math.round((Math.random() - 0.5) * 4))),
        }))
      );
    }, 2000);
    return () => clearInterval(t);
  }, []);

  const wh = liveData.find((w) => w.id === selected) ?? liveData[0];

  function restock() {
    toast.success("أُرسل أمر إعادة التموين تلقائياً", {
      description: "GLM 5.2 حدّد الكميات والموردين الأفضل — وصلت 3 أوامر شراء",
    });
  }

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-2xl font-bold">المخازن</h1>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-teal-500/15 text-teal-400 border border-teal-500/20 flex items-center gap-1">
              <Icon name="activity" className="w-2.5 h-2.5" />
              IoT مباشر
            </span>
          </div>
          <p className="text-xs text-muted-foreground mt-0.5">مراقبة لّحظية لـ 4 مخازن بتقنية إنترنت الأشياء</p>
        </div>
        <button
          onClick={restock}
          className="px-3 py-2 rounded-xl bg-gradient-to-r from-emerald-500/20 to-teal-500/20 border border-emerald-500/30 text-xs font-medium hover:border-emerald-500/50 transition flex items-center gap-1.5"
        >
          <Icon name="brain" className="w-3.5 h-3.5 text-emerald-400" />
          إعادة تمويل ذكية
        </button>
      </div>

      {/* Warehouse cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3">
        {liveData.map((w) => {
          const usage = (w.used / w.capacity) * 100;
          const isActive = w.id === selected;
          return (
            <button
              key={w.id}
              onClick={() => setSelected(w.id)}
              className={`glass rounded-2xl p-4 text-right transition hover:scale-[1.01] ${
                isActive ? "border-emerald-500/40 glow-emerald" : "border-white/5"
              }`}
            >
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <div className="w-8 h-8 rounded-lg bg-teal-500/15 flex items-center justify-center">
                      <Icon name="boxes" className="w-4 h-4 text-teal-400" />
                    </div>
                    <span className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-emerald-400 rounded-full pulse-glow" />
                  </div>
                  <div>
                    <div className="text-xs font-semibold">{w.name}</div>
                    <div className="text-[9px] text-muted-foreground">{w.location}</div>
                  </div>
                </div>
                {usage > 70 && (
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-400">قارب الامتلاء</span>
                )}
              </div>
              <div className="space-y-1.5">
                <div className="flex items-center justify-between text-[10px]">
                  <span className="text-muted-foreground">السعة المستخدمة</span>
                  <span className="num font-medium">{usage.toFixed(1)}%</span>
                </div>
                <div className="h-1.5 rounded-full bg-muted overflow-hidden">
                  <div
                    className={`h-full rounded-full transition-all ${
                      usage > 80 ? "bg-red-400" : usage > 60 ? "bg-amber-400" : "bg-emerald-400"
                    }`}
                    style={{ width: `${usage}%` }}
                  />
                </div>
                <div className="flex items-center justify-between text-[9px] text-muted-foreground pt-1">
                  <span className="flex items-center gap-1">
                    <Icon name="activity" className="w-2.5 h-2.5 text-teal-400" />
                    <span className="num">{w.temp}°م</span>
                  </span>
                  <span className="flex items-center gap-1">
                    <Icon name="globe" className="w-2.5 h-2.5 text-teal-400" />
                    <span className="num">{w.humidity}% رطوبة</span>
                  </span>
                </div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Detail panel */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-5">
        {/* Live telemetry */}
        <div className="glass rounded-2xl p-5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold flex items-center gap-2">
              <Icon name="radar" className="w-4 h-4 text-teal-400" />
              قراءات لحظية
            </h3>
            <span className="text-[9px] text-muted-foreground flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full pulse-glow" />
              يحدّث كل 2 ثانية
            </span>
          </div>
          <div className="text-center py-2">
            <div className="text-[10px] text-muted-foreground mb-1">{wh.name}</div>
            <div className="text-4xl font-bold num gradient-text">{wh.temp}°</div>
            <div className="text-[10px] text-muted-foreground mt-1">درجة الحرارة</div>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Gauge label="الرطوبة" value={wh.humidity} max={100} unit="%" color="teal" />
            <Gauge label="الاستخدام" value={wh.used} max={wh.capacity} unit="" color="emerald" />
            <Gauge label="عدد الأصناف" value={wh.items} max={2000} unit="" color="gold" />
            <Gauge label="مؤشر الذكاء" value={Math.round(wh.aiStock * 100)} max={100} unit="%" color="magenta" />
          </div>
        </div>

        {/* Predictive restock */}
        <div className="glass rounded-2xl p-5 xl:col-span-2">
          <h3 className="text-sm font-semibold flex items-center gap-2 mb-3">
            <Icon name="brain" className="w-4 h-4 text-emerald-400" />
            توقعات إعادة التموين
          </h3>
          <div className="space-y-2">
            {[
              { item: "كرسي مكتب فاخر (ITM-001)", current: 124, predicted: 18, days: 6, urgency: "high" },
              { item: "طاولة اجتماعات L (ITM-002)", current: 38, predicted: 12, days: 14, urgency: "medium" },
              { item: "خزانة ملفات (ITM-003)", current: 8, predicted: 2, days: 3, urgency: "critical" },
              { item: "شاشة عرض 55 بوصة (ITM-004)", current: 22, predicted: 7, days: 18, urgency: "low" },
              { item: "حاسب ProBook (ITM-006)", current: 6, predicted: 1, days: 4, urgency: "critical" },
            ].map((r) => (
              <div key={r.item} className="flex items-center gap-3 p-2.5 rounded-xl bg-white/[0.02] hover:bg-white/5 transition">
                <div className={`w-1 self-stretch rounded-full ${
                  r.urgency === "critical" ? "bg-red-400" : r.urgency === "high" ? "bg-amber-400" : r.urgency === "medium" ? "bg-teal-400" : "bg-emerald-400"
                }`} />
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-medium truncate">{r.item}</div>
                  <div className="text-[9px] text-muted-foreground num">
                    المتاح: {r.current} · متوقع النفاد: {r.days} أيام
                  </div>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-[10px] text-muted-foreground">موصى به</div>
                  <div className="text-xs font-bold text-emerald-400 num">{r.predicted} وحدة</div>
                </div>
              </div>
            ))}
          </div>
          <div className="mt-3 p-2.5 rounded-xl bg-emerald-500/5 border border-emerald-500/20 text-[10px] text-muted-foreground">
            <Icon name="info" className="w-3 h-3 inline text-emerald-400 ml-1" />
            خوارزمية أوميغا تحلّل 12 متغيراً (موسم، اتجاه، توريد، تكرار) لاقتراح كميات إعادة التموين المثلى.
          </div>
        </div>
      </div>
    </div>
  );
}

function Gauge({ label, value, max, unit, color }: { label: string; value: number; max: number; unit: string; color: string }) {
  const pct = Math.min((value / max) * 100, 100);
  const colorMap: Record<string, string> = {
    emerald: "from-emerald-500/60 to-emerald-400 text-emerald-400",
    teal: "from-teal-500/60 to-teal-400 text-teal-400",
    gold: "from-amber-500/60 to-amber-400 text-amber-400",
    magenta: "from-pink-500/60 to-pink-400 text-pink-400",
  };
  return (
    <div className="glass rounded-xl p-2.5">
      <div className="text-[9px] text-muted-foreground mb-1">{label}</div>
      <div className="flex items-end gap-1">
        <span className={`text-lg font-bold num ${colorMap[color].split(" ").pop()}`}>{value}</span>
        {unit && <span className="text-[9px] text-muted-foreground mb-0.5">{unit}</span>}
      </div>
      <div className="h-1 rounded-full bg-muted overflow-hidden mt-1">
        <div className={`h-full bg-gradient-to-r ${colorMap[color]}`} style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}
