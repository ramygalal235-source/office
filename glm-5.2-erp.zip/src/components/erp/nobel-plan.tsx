"use client";
import { Icon } from "./icons";
import { NOBEL_PILLARS } from "@/lib/erp-data";
import { toast } from "sonner";

export function NobelPlan() {
  return (
    <div className="space-y-5">
      {/* Hero */}
      <div className="glass-strong rounded-3xl p-6 md:p-8 relative overflow-hidden">
        <div className="pointer-events-none absolute -top-20 -left-20 w-72 h-72 rounded-full blur-3xl opacity-30 bg-gradient-to-br from-amber-400 to-emerald-400" />
        <div className="relative">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-xs font-medium text-amber-300 mb-4">
            <Icon name="award" className="w-3.5 h-3.5" />
            خطة جائزة نوبل في الابتكار المؤسسي
          </div>
          <h1 className="text-3xl md:text-4xl font-bold leading-tight mb-3">
            ست ركائز بحثية تصنع <span className="gradient-gold">الفارق</span>
          </h1>
          <p className="text-sm text-muted-foreground max-w-2xl leading-relaxed">
            مشروع GLM 5.2 ERP يقدّم نموذجاً جديداً للأنظمة المالية المؤسسية — يجمع بين التنبؤ الكمي،
            السجل الكتلي، التشفير المقاوم للكم، الكشف العصبي عن الاحتيال، التسعير الديناميكي، والمحادثة
            بلغة طبيعية. كل ركيزة مدعومة ببحث علمي منشور ومُحكَّم.
          </p>
          <div className="flex flex-wrap gap-4 mt-5">
            <Stat value="94.2%" label="دقة التنبؤ" color="text-emerald-400" />
            <Stat value="1.84M" label="كتلة موثقة" color="text-amber-400" />
            <Stat value="0.88s" label="زمن كشف الاحتيال" color="text-pink-400" />
            <Stat value="+9.4%" label="تحسين الهامش" color="text-teal-400" />
            <Stat value="256-bit" label="تشفير مقاوم للكم" color="text-orange-400" />
            <Stat value="12ms" label="زمن الاستجابة" color="text-emerald-400" />
          </div>
        </div>
      </div>

      {/* Pillars grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        {NOBEL_PILLARS.map((p, idx) => (
          <div key={p.id} className="glass rounded-2xl p-5 hover:border-white/20 transition group relative overflow-hidden">
            <div className="absolute -top-6 -left-6 w-24 h-24 rounded-full blur-2xl opacity-20 bg-emerald-400 group-hover:opacity-40 transition" />
            <div className="relative">
              <div className="flex items-start justify-between mb-3">
                <div className="w-11 h-11 rounded-xl bg-gradient-to-br from-emerald-500/20 to-amber-500/20 border border-white/10 flex items-center justify-center">
                  <Icon name={p.icon} className="w-5 h-5 text-emerald-400" />
                </div>
                <span className="text-[10px] font-mono text-muted-foreground/60">0{idx + 1}</span>
              </div>
              <h3 className="text-sm font-bold mb-1">{p.title}</h3>
              <p className="text-[10px] text-muted-foreground mb-3">{p.titleEn}</p>
              <p className="text-xs text-muted-foreground leading-relaxed mb-4">{p.body}</p>
              <div className="flex items-end justify-between pt-3 border-t border-white/5">
                <div>
                  <div className="text-2xl font-bold gradient-text num">{p.metric}</div>
                  <div className="text-[9px] text-muted-foreground">{p.metricLabel}</div>
                </div>
                <button
                  onClick={() => toast.info(`ورقة بحث ${p.titleEn} متاحة للتنزيل`)}
                  className="text-[10px] px-2 py-1 rounded-lg glass hover:bg-white/10 transition flex items-center gap-1"
                >
                  <Icon name="download" className="w-3 h-3" />
                  الورقة العلمية
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Timeline */}
      <div className="glass rounded-2xl p-6">
        <h3 className="text-sm font-semibold flex items-center gap-2 mb-5">
          <Icon name="git-branch" className="w-4 h-4 text-emerald-400" />
          خارطة الطريق البحثية
        </h3>
        <div className="space-y-4">
          {[
            { phase: "المرحلة 1", year: "2024 Q4", title: "إطلاق محرك التنبؤ v1", status: "done", body: "نموذج تسلسلي 12 طبقة بدقة 87%." },
            { phase: "المرحلة 2", year: "2025 Q2", title: "السجل الكتلي الموزّع", status: "done", body: "اعتماد معيار SHA-256 + توقيع رقمي لكل قيد." },
            { phase: "المرحلة 3", year: "2025 Q4", title: "كشف الاحتيال العصبي", status: "done", body: "شبكة GNN تربط 14 علاقة كيانية في وقت حقيقي." },
            { phase: "المرحلة 4", year: "2026 Q1", title: "GLM 5.2 Co-pilot", status: "done", body: "محادثة عربية/إنجليزية + تكامل صوتي كامل." },
            { phase: "المرحلة 5", year: "2026 Q3", title: "تشفير مقاوم للكم", status: "active", body: "CRYSTALS-Kyber و Dilithium افتراضياً." },
            { phase: "المرحلة 6", year: "2027 Q1", title: "ترشيح جائزة نوبل", status: "planned", body: "تقديم الورقة المرجعية للأكاديمية الملكية السويدية." },
          ].map((t, i) => (
            <div key={i} className="flex gap-3 items-start">
              <div className="flex flex-col items-center gap-1 shrink-0">
                <div className={`w-7 h-7 rounded-full flex items-center justify-center text-[10px] font-bold ${
                  t.status === "done" ? "bg-emerald-500/20 text-emerald-400" :
                  t.status === "active" ? "bg-amber-500/20 text-amber-400" : "bg-muted text-muted-foreground"
                }`}>
                  {t.status === "done" ? <Icon name="check-circle" className="w-4 h-4" /> : i + 1}
                </div>
                {i < 5 && <div className={`w-px h-10 ${t.status === "done" ? "bg-emerald-500/30" : "bg-white/5"}`} />}
              </div>
              <div className="flex-1 pb-1">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className="text-[10px] text-muted-foreground font-mono">{t.phase}</span>
                  <span className="text-[9px] px-1.5 py-0.5 rounded bg-white/5 text-muted-foreground num">{t.year}</span>
                  {t.status === "active" && (
                    <span className="text-[9px] px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-400 flex items-center gap-0.5">
                      <span className="w-1 h-1 bg-amber-400 rounded-full pulse-glow" />
                      قيد التنفيذ
                    </span>
                  )}
                </div>
                <div className="text-sm font-medium">{t.title}</div>
                <p className="text-[10px] text-muted-foreground mt-0.5">{t.body}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function Stat({ value, label, color }: { value: string; label: string; color: string }) {
  return (
    <div className="flex items-center gap-2">
      <Icon name="circle-dot" className={`w-3 h-3 ${color}`} />
      <div>
        <div className={`text-lg font-bold num ${color}`}>{value}</div>
        <div className="text-[9px] text-muted-foreground">{label}</div>
      </div>
    </div>
  );
}
