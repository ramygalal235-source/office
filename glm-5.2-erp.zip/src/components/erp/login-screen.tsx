"use client";
import { useState, useEffect } from "react";
import { BRANCHES, USERS } from "@/lib/erp-data";
import { Icon } from "./icons";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";

type Props = {
  onLogin: (branchId: string, userId: string) => void;
};

export function LoginScreen({ onLogin }: Props) {
  const [branchId, setBranchId] = useState("");
  const [userId, setUserId] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [tick, setTick] = useState(0);

  // Live clock
  const [now, setNow] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);

  // Background animation tick
  useEffect(() => {
    const t = setInterval(() => setTick((x) => (x + 1) % 1000), 80);
    return () => clearInterval(t);
  }, []);

  const availableUsers = USERS.filter((u) => !branchId || u.branchId === branchId);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!branchId) return toast.error("اختر الفرع أولاً");
    if (!userId) return toast.error("اختر المستخدم");
    if (!password) return toast.error("أدخل كلمة المرور");
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      onLogin(branchId, userId);
      toast.success("تم تسجيل الدخول بنجاح", { description: "مرحباً بك في GLM 5.2 ERP" });
    }, 1100);
  }

  const timeStr = now.toLocaleTimeString("ar-EG", { hour: "2-digit", minute: "2-digit", second: "2-digit" });
  const dateStr = now.toLocaleDateString("ar-EG", { weekday: "long", year: "numeric", month: "long", day: "numeric" });

  return (
    <div className="min-h-screen relative overflow-hidden grid-bg">
      {/* Animated background orbs */}
      <div className="pointer-events-none absolute inset-0">
        <div
          className="absolute -top-40 -right-40 w-96 h-96 rounded-full blur-3xl opacity-30"
          style={{
            background: "radial-gradient(circle, oklch(0.72 0.18 162) 0%, transparent 70%)",
            transform: `translate(${Math.sin(tick / 30) * 30}px, ${Math.cos(tick / 30) * 30}px)`,
          }}
        />
        <div
          className="absolute -bottom-40 -left-40 w-96 h-96 rounded-full blur-3xl opacity-25"
          style={{
            background: "radial-gradient(circle, oklch(0.78 0.16 84) 0%, transparent 70%)",
            transform: `translate(${Math.cos(tick / 40) * 40}px, ${Math.sin(tick / 40) * 40}px)`,
          }}
        />
      </div>

      <div className="relative z-10 min-h-screen grid lg:grid-cols-2">
        {/* Left — Hero */}
        <div className="hidden lg:flex flex-col justify-between p-12 border-l border-white/5">
          <div className="flex items-center gap-3">
            <div className="relative">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center glow-emerald">
                <Icon name="atom" className="w-7 h-7 text-black" />
              </div>
              <div className="absolute -top-1 -right-1 w-3 h-3 bg-emerald-400 rounded-full pulse-glow" />
            </div>
            <div>
              <div className="text-2xl font-bold tracking-tight">GLM <span className="gradient-text">5.2</span></div>
              <div className="text-xs text-muted-foreground">Nobel-grade Enterprise Suite</div>
            </div>
          </div>

          <div className="space-y-8">
            <div className="space-y-3">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full glass text-xs font-medium text-emerald-300">
                <Icon name="award" className="w-3.5 h-3.5" />
                الحاصل على وسام الابتكار المؤسسي 2026
              </div>
              <h1 className="text-5xl font-bold leading-tight tracking-tight">
                نظام موارد المؤسسة
                <br />
                <span className="gradient-text">المعتمد على الذكاء الاصطناعي</span>
              </h1>
              <p className="text-lg text-muted-foreground max-w-md leading-relaxed">
                منصة موحدة تجمع التنبؤ الكمي، السجل الكتلي، التشفير المقاوم للكم، ومحرك التسعير الديناميكي في تجربة عربية أصيلة.
              </p>
            </div>

            <div className="grid grid-cols-2 gap-3 max-w-md">
              {[
                { icon: "brain", label: "محرك تنبؤ 94.2%", color: "text-emerald-400" },
                { icon: "shield", label: "سجل كتلي موثق", color: "text-amber-400" },
                { icon: "lock", label: "تشفير مقاوم للكم", color: "text-pink-400" },
                { icon: "bot", label: "مساعد ذكي صوتي", color: "text-teal-400" },
              ].map((f) => (
                <div key={f.label} className="glass rounded-xl p-3 flex items-center gap-2.5">
                  <Icon name={f.icon} className={`w-5 h-5 ${f.color}`} />
                  <span className="text-sm">{f.label}</span>
                </div>
              ))}
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <div className="flex items-center gap-2">
              <div className="w-2 h-2 bg-emerald-400 rounded-full pulse-glow" />
              <span>النظام يعمل بكفاءة</span>
            </div>
            <div className="num">{dateStr} • {timeStr}</div>
          </div>
        </div>

        {/* Right — Login form */}
        <div className="flex items-center justify-center p-6 lg:p-12">
          <div className="w-full max-w-md">
            {/* Mobile brand */}
            <div className="lg:hidden flex items-center gap-3 mb-8 justify-center">
              <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center">
                <Icon name="atom" className="w-7 h-7 text-black" />
              </div>
              <div>
                <div className="text-2xl font-bold">GLM <span className="gradient-text">5.2</span></div>
                <div className="text-xs text-muted-foreground">ERP</div>
              </div>
            </div>

            <div className="glass-strong rounded-3xl p-8 border border-white/10 shadow-2xl">
              <div className="space-y-1 mb-7">
                <div className="flex items-center gap-2">
                  <h2 className="text-2xl font-bold">تسجيل الدخول</h2>
                  <Icon name="sparkles" className="w-5 h-5 text-amber-400" />
                </div>
                <p className="text-sm text-muted-foreground">اختر الفرع والمستخدم وأدخل كلمة المرور</p>
              </div>

              <form onSubmit={handleSubmit} className="space-y-4">
                {/* Branch */}
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                    <Icon name="building" className="w-3.5 h-3.5" />
                    الفرع
                  </label>
                  <div className="relative">
                    <select
                      value={branchId}
                      onChange={(e) => { setBranchId(e.target.value); setUserId(""); }}
                      className="w-full appearance-none bg-input/50 border border-border/60 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary/40 transition"
                    >
                      <option value="">اختر الفرع</option>
                      {BRANCHES.map((b) => (
                        <option key={b.id} value={b.id}>{b.nameAr}</option>
                      ))}
                    </select>
                    <Icon name="chevron-down" className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                  </div>
                </div>

                {/* User */}
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                    <Icon name="user" className="w-3.5 h-3.5" />
                    المستخدم
                  </label>
                  <div className="relative">
                    <select
                      value={userId}
                      onChange={(e) => setUserId(e.target.value)}
                      disabled={!branchId}
                      className="w-full appearance-none bg-input/50 border border-border/60 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary/40 transition disabled:opacity-40 disabled:cursor-not-allowed"
                    >
                      <option value="">اختر المستخدم</option>
                      {availableUsers.map((u) => (
                        <option key={u.id} value={u.id}>{u.name}</option>
                      ))}
                    </select>
                    <Icon name="chevron-down" className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground pointer-events-none" />
                  </div>
                </div>

                {/* Password */}
                <div className="space-y-1.5">
                  <label className="text-xs font-medium text-muted-foreground flex items-center gap-1.5">
                    <Icon name="lock" className="w-3.5 h-3.5" />
                    كلمة المرور
                  </label>
                  <div className="relative">
                    <input
                      type={showPassword ? "text" : "password"}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="أدخل كلمة المرور"
                      className="w-full bg-input/50 border border-border/60 rounded-xl px-4 py-3 pl-11 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary/40 transition"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((s) => !s)}
                      className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground transition"
                      aria-label="إظهار/إخفاء كلمة المرور"
                    >
                      <Icon name={showPassword ? "eye-off" : "eye"} className="w-4 h-4" />
                    </button>
                  </div>
                  <p className="text-[10px] text-muted-foreground/70 pt-1 flex items-center gap-1">
                    <Icon name="info" className="w-3 h-3" />
                    تجريبياً: كلمة المرور لأي حساب هي <code className="px-1 py-0.5 bg-muted/50 rounded text-emerald-400">1</code>
                  </p>
                </div>

                {/* Remember + biometric */}
                <div className="flex items-center justify-between text-xs">
                  <label className="flex items-center gap-2 cursor-pointer">
                    <input type="checkbox" defaultChecked className="rounded accent-emerald-500" />
                    <span>تذكرني</span>
                  </label>
                  <button type="button" className="flex items-center gap-1.5 text-muted-foreground hover:text-emerald-400 transition">
                    <Icon name="fingerprint" className="w-3.5 h-3.5" />
                    دخول بالبصمة
                  </button>
                </div>

                <Button
                  type="submit"
                  disabled={loading}
                  className="w-full h-12 text-sm font-semibold bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-black shadow-lg shadow-emerald-500/20 transition"
                >
                  {loading ? (
                    <span className="flex items-center gap-2">
                      <Icon name="activity" className="w-4 h-4 animate-spin" />
                      جارٍ المصادقة...
                    </span>
                  ) : (
                    <span className="flex items-center gap-2">
                      تسجيل الدخول
                      <Icon name="chevron-left" className="w-4 h-4" />
                    </span>
                  )}
                </Button>
              </form>

              <div className="mt-6 pt-5 border-t border-white/5 flex items-center justify-between text-[10px] text-muted-foreground/70">
                <div className="flex items-center gap-1.5">
                  <Icon name="shield" className="w-3 h-3 text-emerald-400" />
                  محمي بتشفير 256-bit
                </div>
                <div className="flex items-center gap-1.5">
                  <Icon name="globe" className="w-3 h-3" />
                  v5.2.0 — Nobel Edition
                </div>
              </div>
            </div>

            <div className="mt-6 text-center text-xs text-muted-foreground">
              © 2026 GLM 5.2 Labs · جميع الحقوق محفوظة
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
