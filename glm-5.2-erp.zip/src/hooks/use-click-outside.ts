"use client";
import { useEffect, type RefObject } from "react";

/**
 * Hook that triggers a callback when a click/touch occurs outside the referenced element.
 * Replaces the `<div className="fixed inset-0">` backdrop pattern that blocks adjacent buttons.
 */
export function useClickOutside<T extends HTMLElement>(
  ref: RefObject<T | null>,
  handler: () => void,
  enabled: boolean = true,
  excludedRefs: Array<RefObject<HTMLElement | null>> = []
) {
  useEffect(() => {
    if (!enabled) return;

    function listener(event: MouseEvent | TouchEvent) {
      const el = ref.current;
      if (!el || el.contains(event.target as Node)) return;
      // Don't close if click is on any excluded element (e.g. the trigger button)
      for (const ex of excludedRefs) {
        if (ex.current && ex.current.contains(event.target as Node)) return;
      }
      handler();
    }

    document.addEventListener("mousedown", listener);
    document.addEventListener("touchstart", listener);
    return () => {
      document.removeEventListener("mousedown", listener);
      document.removeEventListener("touchstart", listener);
    };
  }, [ref, handler, enabled, excludedRefs]);
}
