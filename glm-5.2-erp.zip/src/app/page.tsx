"use client";
import { useState, useEffect } from "react";
import { LoginScreen } from "@/components/erp/login-screen";
import { Sidebar, type ModuleKey } from "@/components/erp/sidebar";
import { Topbar } from "@/components/erp/topbar";
import { AICopilot } from "@/components/erp/ai-copilot";
import { Dashboard } from "@/components/erp/dashboard";
import { SalesModule } from "@/components/erp/sales-module";
import { WarehousesModule } from "@/components/erp/warehouses-module";
import { NobelPlan } from "@/components/erp/nobel-plan";
import { ReportsModule, TreasuryModule, CalendarModule, SettingsModule, PlaceholderModule } from "@/components/erp/other-modules";

export default function Home() {
  const [authed, setAuthed] = useState(false);
  const [branchId, setBranchId] = useState("");
  const [userId, setUserId] = useState("");
  const [active, setActive] = useState<ModuleKey>("dashboard");
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [copilotOpen, setCopilotOpen] = useState(false);
  const [theme, setTheme] = useState<"dark" | "light">("light");
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    // responsive sidebar collapse on small screens
    const onResize = () => setSidebarCollapsed(window.innerWidth < 1024);
    // eslint-disable-next-line react-hooks/set-state-in-effect
    if (window.innerWidth < 1024) setSidebarCollapsed(true);
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  // Mark mounted after first paint to avoid SSR/hydration mismatch
  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect
    setMounted(true);
  }, []);

  useEffect(() => {
    if (theme === "dark") document.documentElement.classList.add("dark");
    else document.documentElement.classList.remove("dark");
  }, [theme]);

  // Keyboard shortcut: Cmd/Ctrl+K to open copilot
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setCopilotOpen((v) => !v);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  function handleLogin(b: string, u: string) {
    setBranchId(b);
    setUserId(u);
    setAuthed(true);
  }

  function handleLogout() {
    setAuthed(false);
    setBranchId("");
    setUserId("");
    setActive("dashboard");
  }

  if (!mounted) return null;

  if (!authed) {
    return <LoginScreen onLogin={handleLogin} />;
  }

  return (
    <div className="min-h-screen flex bg-background text-foreground">
      <Sidebar
        active={active}
        onNavigate={setActive}
        collapsed={sidebarCollapsed}
        onToggleCollapse={() => setSidebarCollapsed((v) => !v)}
      />
      <div className="flex-1 flex flex-col min-w-0">
        <Topbar
          branchId={branchId}
          userId={userId}
          onOpenCopilot={() => setCopilotOpen(true)}
          onLogout={handleLogout}
          onToggleTheme={() => setTheme((t) => (t === "dark" ? "light" : "dark"))}
          theme={theme}
        />
        <main className="flex-1 p-4 lg:p-6 overflow-x-hidden">
          <div className="max-w-[1600px] mx-auto float-up" key={active}>
            {active === "dashboard" && <Dashboard />}
            {active === "sales" && <SalesModule />}
            {active === "warehouses" && <WarehousesModule />}
            {active === "reports" && <ReportsModule />}
            {active === "treasury" && <TreasuryModule />}
            {active === "calendar" && <CalendarModule />}
            {active === "settings" && <SettingsModule />}
            {active === "nobel" && <NobelPlan />}
            {active === "purchases" && (
              <PlaceholderModule title="المشتريات" icon="shopping-cart" description="إدارة أوامر الشراء والموردين" />
            )}
            {active === "banks" && (
              <PlaceholderModule title="البنوك والشيكات" icon="banknote" description="إدارة الحسابات البنكية والشيكات" />
            )}
            {active === "settlements" && (
              <PlaceholderModule title="التسويات" icon="list" description="تسويات الحسابات والمطابقات" />
            )}
            {active === "system" && (
              <PlaceholderModule title="تعريف النظام" icon="settings" description="إعدادات النظام العامة" />
            )}
            {active === "opening" && (
              <PlaceholderModule title="الأرصدة الافتتاحية" icon="file-text" description="أرصدة بداية المدة" />
            )}
            {active === "assets" && (
              <PlaceholderModule title="الأصول الثابتة" icon="building" description="إدارة الأصول الثابتة والإهلاك" />
            )}
          </div>
        </main>
        <footer className="border-t border-white/5 bg-background/50 px-4 py-2.5 flex items-center justify-between text-[10px] text-muted-foreground">
          <div className="flex items-center gap-3">
            <span className="flex items-center gap-1">
              <span className="w-1.5 h-1.5 bg-emerald-400 rounded-full pulse-glow" />
              GLM 5.2 ERP · Nobel Edition
            </span>
            <span className="hidden sm:inline">v5.2.0</span>
          </div>
          <div className="flex items-center gap-3">
            <span className="hidden sm:inline">محمي بتشفير مقاوم للكم</span>
            <span>© 2026 GLM 5.2 Labs</span>
          </div>
        </footer>
      </div>

      <AICopilot open={copilotOpen} onClose={() => setCopilotOpen(false)} />
    </div>
  );
}
