import type { Metadata } from "next";
import { Cairo, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as SonnerToaster } from "@/components/ui/sonner";

const cairo = Cairo({
  variable: "--font-arabic",
  subsets: ["arabic", "latin"],
  weight: ["300", "400", "500", "600", "700", "800", "900"],
  display: "swap",
});

const plexMono = IBM_Plex_Mono({
  variable: "--font-mono",
  subsets: ["latin"],
  weight: ["400", "500", "600"],
  display: "swap",
});

export const metadata: Metadata = {
  title: "GLM 5.2 ERP — Noble-Grade Enterprise Suite",
  description:
    "GLM 5.2 ERP — نظام موارد تخطيط المؤسسات المدعوم بالذكاء الاصطناعي. الحاصل على جائزة نوبل الترفيهية للابتكار في الأنظمة المالية.",
  keywords: ["GLM 5.2", "ERP", "AI", "Nobel Prize", "ذكاء اصطناعي", "موارد المؤسسات"],
  authors: [{ name: "GLM 5.2 Labs" }],
  icons: { icon: "https://z-cdn.chatglm.cn/z-ai/static/logo.svg" },
  openGraph: {
    title: "GLM 5.2 ERP — Noble-Grade Enterprise Suite",
    description: "AI-native ERP with predictive analytics, blockchain audit trails, and quantum-safe encryption.",
    siteName: "GLM 5.2 ERP",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ar" dir="rtl" suppressHydrationWarning className={`${cairo.variable} ${plexMono.variable}`}>
      <body className="min-h-screen antialiased">
        {children}
        <Toaster />
        <SonnerToaster position="top-center" richColors closeButton />
      </body>
    </html>
  );
}
