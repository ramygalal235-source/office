import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone",
  typescript: {
    ignoreBuildErrors: false,
  },
  reactStrictMode: true,
  // Allow the preview/sandbox origin to access _next resources
  allowedDevOrigins: ["*.space-z.ai", "*.chatglm.cn"],
  // Disable the floating dev-tools indicator (bottom-right) that was covering UI elements
  devIndicators: false,
  productionBrowserSourceMaps: false,
};

export default nextConfig;
