# GLM 5.2 ERP — Nobel Edition

نظام موارد تخطيط المؤسسات المدعوم بالذكاء الاصطناعي.
A Nobel-grade, AI-first Arabic ERP system built with Next.js 16, TypeScript, and Tailwind CSS 4.

![GLM 5.2 ERP](https://img.shields.io/badge/version-5.2.0-emerald) ![Next.js](https://img.shields.io/badge/Next.js-16-black) ![TypeScript](https://img.shields.io/badge/TypeScript-5-blue) ![License](https://img.shields.io/badge/license-MIT-gold)

## ✨ Highlights

- **RTL Arabic-first** UI with Cairo font + IBM Plex Mono
- **Light/Dark theme** with emerald + gold premium palette
- **AI Co-pilot** chat panel (Cmd+K) with forecast & risk analysis mini-charts
- **Live IoT telemetry** for warehouses (updates every 2s)
- **AI invoice generator** with smart pricing & customer risk analysis
- **Blockchain audit trail** with hashed ledger entries
- **14 ERP modules**: Dashboard, Sales, Purchases, Warehouses, Treasury, Banks, Settlements, Reports, Calendar, System Def, Opening Balances, Fixed Assets, Nobel Plan, Settings
- **Nobel Plan page** showcasing 6 research pillars (Quantum Prediction, Blockchain Audit, Quantum-Safe Encryption, Neural Fraud Detection, Dynamic Pricing, NL Co-pilot)

## 🚀 Quick Start

```bash
# Install dependencies
bun install

# Push Prisma schema (optional, demo uses mock data)
bun run db:push

# Start dev server
bun run dev
# → http://localhost:3000

# Build for production
bun run build
bun run start
```

## 🔑 Demo Login

| Field    | Value             |
|----------|-------------------|
| Branch   | الفرع الرئيسى     |
| User     | Admin             |
| Password | `1`               |

(Any branch + any user + password `1` works.)

## 📁 Project Structure

```
src/
├── app/
│   ├── globals.css          # Nobel-grade palette (light + dark)
│   ├── layout.tsx           # RTL Arabic layout with Cairo font
│   └── page.tsx             # Auth gate + module router
├── components/
│   ├── erp/
│   │   ├── icons.tsx           # Lucide icon registry
│   │   ├── login-screen.tsx    # Branch/user/password login
│   │   ├── sidebar.tsx         # 14-module navigation
│   │   ├── topbar.tsx          # Search, alerts, user menu, theme toggle
│   │   ├── ai-copilot.tsx      # GLM 5.2 chat panel
│   │   ├── dashboard.tsx       # KPIs, charts, analytics, blockchain trail
│   │   ├── sales-module.tsx    # AI invoice generator
│   │   ├── warehouses-module.tsx  # Live IoT telemetry
│   │   ├── nobel-plan.tsx      # 6 research pillars + roadmap
│   │   └── other-modules.tsx   # Reports, Treasury, Calendar, Settings
│   └── ui/                     # shadcn/ui components
├── hooks/
│   ├── use-click-outside.ts    # Dropdown dismissal hook
│   ├── use-mobile.ts
│   └── use-toast.ts
└── lib/
    ├── erp-data.ts          # Centralized mock data store
    ├── db.ts                # Prisma client
    └── utils.ts             # cn() helper
```

## 🛠 Tech Stack

- **Framework**: Next.js 16 (App Router, Turbopack)
- **Language**: TypeScript 5
- **Styling**: Tailwind CSS 4 + shadcn/ui (New York)
- **Fonts**: Cairo (Arabic) + IBM Plex Mono
- **Icons**: lucide-react
- **Toasts**: sonner + radix toast
- **Database**: Prisma ORM (SQLite) — optional, demo uses mock data

## ⌨️ Keyboard Shortcuts

| Shortcut | Action                |
|----------|-----------------------|
| `Cmd+K`  | Open AI Co-pilot      |
| `Esc`    | Close copilot/dropdowns |

## 🎨 Design Tokens

- **Primary**: Emerald (`oklch(0.55 0.16 162)` light / `oklch(0.72 0.18 162)` dark)
- **Accent**: Gold (`oklch(0.72 0.16 84)`)
- **Background**: Obsidian (`oklch(0.14 0.012 240)`) in dark, near-white in light
- **Radius**: `0.75rem`
- **Glassmorphism**: `.glass` and `.glass-strong` utilities

## 📦 Production Notes

- `next.config.ts` disables `devIndicators` to prevent the floating dev-tools button from blocking UI
- `allowedDevOrigins` permits the sandbox preview origin
- `output: "standalone"` for containerized deployment
- All components are client-rendered (`'use client'`) for interactivity

## 📄 License

MIT © 2026 GLM 5.2 Labs
